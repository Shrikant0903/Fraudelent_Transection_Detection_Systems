from nexttoken import NextToken
import os
import base64
import time

client = NextToken()

REPO_NAME = "fraud-guard-pro"
DESCRIPTION = "Fraud Guard Pro: Advanced Security Operations Center (SOC) for Real-time Fraud Detection with RBAC and Indian Currency Support."

# Files to upload
FILES_TO_UPLOAD = [
    "apps/fraud_detector/backend/main.py",
    "apps/fraud_detector/backend/services.py",
    "apps/fraud_detector/backend/db.py",
    "apps/fraud_detector/backend/requirements.txt",
    "apps/fraud_detector/frontend/src/App.tsx",
    "apps/fraud_detector/frontend/src/api.ts",
    "apps/fraud_detector/frontend/src/features/analytics-overview.tsx",
    "apps/fraud_detector/frontend/src/features/prediction-tool.tsx",
    "apps/fraud_detector/frontend/src/features/transaction-audit.tsx",
    "apps/fraud_detector/frontend/src/features/user-management.tsx",
    "apps/fraud_detector/frontend/package.json",
    "apps/fraud_detector/frontend/tailwind.config.js",
    "apps/fraud_detector/frontend/vite.config.ts",
    "README.md",
    "requirements.txt"
]

def push_to_github():
    print(f"[GITHUB_START] Initializing push to GitHub for '{REPO_NAME}'...")
    
    # 1. Verify GitHub integration is connected via SDK
    try:
        integrations = client.integrations.list()
        github_connected = any(i.get("app") == "github" for i in integrations)
        if not github_connected:
            print("[GITHUB_ERROR] GitHub integration not found. Please connect it first.")
            return
        print("[GITHUB_STEP] GitHub integration confirmed.")
    except Exception as e:
        print(f"[GITHUB_ERROR] Failed to list integrations: {str(e)}")
        return

    # 2. Check for existence of the repository via the 'List Repositories' action
    print(f"[GITHUB_STEP] Checking if repository '{REPO_NAME}' exists...")
    try:
        list_result = client.integrations.invoke(
            app="github",
            function_key="github-list-repositories",
            args={"affiliation": ["owner"], "sort": "created", "direction": "desc"}
        )
        repos = list_result.get("result", {}).get("ret", [])
        repo_exists = any(r.get("name") == REPO_NAME for r in repos)
        
        # If not exists, we use the 'Create Repository' action (if available) or inform user
        if not repo_exists:
            print(f"[GITHUB_STEP] Creating public repository '{REPO_NAME}'...")
            # Pipedream action: github-create-repository
            create_result = client.integrations.invoke(
                app="github",
                function_key="github-create-repository",
                args={
                    "name": REPO_NAME,
                    "description": DESCRIPTION,
                    "private": False
                }
            )
            print(f"[GITHUB_SUCCESS] Repository created.")
        else:
            print(f"[GITHUB_INFO] Repository '{REPO_NAME}' already exists. Using existing.")
    except Exception as e:
        print(f"[GITHUB_ERROR] Failed repo check/creation: {str(e)}")
        return

    # 3. Upload files using the 'Create or Update File Contents' action
    print(f"[GITHUB_STEP] Starting file uploads...")
    for file_path in FILES_TO_UPLOAD:
        if not os.path.exists(file_path):
            print(f"[GITHUB_WARN] Skipping missing file: {file_path}")
            continue
            
        try:
            with open(file_path, "rb") as f:
                content = base64.b64encode(f.read()).decode("utf-8")
            
            # Pipedream action: github-create-or-update-file-contents
            print(f"[GITHUB_STEP] Uploading {file_path}...")
            upload_result = client.integrations.invoke(
                app="github",
                function_key="github-create-or-update-file-contents",
                args={
                    "repoFullname": f"{{username}}/{{REPO_NAME}}", # This is often just owner/repo
                    "path": file_path,
                    "message": f"Upload {file_path}",
                    "content": content,
                    "branch": "main"
                }
            )
            # The exact name of the prop might vary, we should check it via get_action_details
            # But we'll try this pattern first.
            print(f"[GITHUB_SUCCESS] Uploaded: {file_path}")
            
        except Exception as e:
            print(f"[GITHUB_ERROR] Failed to upload {file_path}: {str(e)}")

    print(f"\n[GITHUB_COMPLETE] Fraud Guard Pro upload finished.")

if __name__ == "__main__":
    push_to_github()
