import React, { useState, useEffect, useCallback } from 'react';
import { AnalyticsOverview } from './features/analytics-overview';
import { PredictionTool } from './features/prediction-tool';
import { TransactionAudit } from './features/transaction-audit';
import { FlaggedUsers } from './features/flagged-users';
import { UserManagement } from './features/user-management';
import { rpcCall } from './api';
import { cn } from './lib/utils';
import { Button } from './components/ui/button';
import { Separator } from './components/ui/separator';
import { Input } from './components/ui/input';
import { Label } from './components/ui/label';
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from './components/ui/card';
import { 
  LayoutDashboard, 
  BrainCircuit, 
  ShieldAlert, 
  Users, 
  Settings, 
  Bell, 
  Search, 
  Menu, 
  ChevronRight,
  LogOut,
  Zap,
  Activity,
  User,
  ShieldCheck,
  Cpu,
  Database,
  Terminal,
  X,
  Lock,
  KeyRound,
  ShieldCheck as ShieldIcon,
  AlertOctagon
} from 'lucide-react';
import { SiSqlite, SiPython, SiScikitlearn, SiGooglecloud } from 'react-icons/si';

export default function App() {
  const [user, setUser] = useState<any>(null);
  const [loginForm, setLoginForm] = useState({ username: '', password: '' });
  const [loginError, setLoginError] = useState('');
  const [activeView, setActiveView] = useState('overview');
  const [isSimulating, setIsSimulating] = useState(false);
  const [sidebarOpen, setSidebarOpen] = useState(true);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  useEffect(() => {
    console.log("RENDER_SUCCESS");
  }, []);

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoginError('');
    try {
      const result = await rpcCall({ func: 'login', args: loginForm });
      if (result) {
        setUser(result);
      } else {
        setLoginError('Invalid security credentials provided.');
      }
    } catch (err) {
      setLoginError('Authentication server unreachable.');
    }
  };

  const handleLogout = () => {
    setUser(null);
  };

  const toggleSimulation = useCallback(async () => {
    if (!isSimulating) {
      console.log("[ACTION_START] toggleSimulation: ON");
      setIsSimulating(true);
      try {
        await rpcCall({ func: 'simulate_transactions', args: { count: 3 } });
      } catch (err) {
        console.error("Simulation trigger failed", err);
      }
    } else {
      console.log("[ACTION_START] toggleSimulation: OFF");
      setIsSimulating(false);
    }
  }, [isSimulating]);

  const navItems = [
    { id: 'overview', label: 'SOC Overview', icon: LayoutDashboard },
    { id: 'prediction', label: 'Risk Vectoring', icon: BrainCircuit },
    { id: 'audit', label: 'Forensic Audit', icon: ShieldAlert },
    { id: 'fraud_users', label: 'Fraud Registry', icon: AlertOctagon },
    { id: 'users', label: 'Access Control', icon: Users },
  ];

  if (!user) {
    return (
      <div className="min-h-screen bg-background flex flex-col items-center justify-center p-4 selection:bg-primary/30 antialiased font-sans">
        <div className="absolute inset-0 bg-[url('./assets/bg-grid.png')] bg-center [mask-image:linear-gradient(180deg,white,rgba(255,255,255,0))] opacity-20 pointer-events-none" />
        
        <div className="w-full max-w-md space-y-8 relative z-10 animate-in fade-in zoom-in-95 duration-1000">
           <div className="text-center space-y-4">
              <div className="mx-auto w-24 h-24 bg-primary/10 rounded-3xl flex items-center justify-center border border-primary/20 shadow-[0_0_50px_rgba(var(--primary-rgb),0.2)] animate-pulse">
                <ShieldIcon className="h-12 w-12 text-primary" />
              </div>
              <div className="space-y-1">
                <h1 className="text-4xl font-heading font-black tracking-tighter uppercase italic">FRAUD<span className="text-primary">GUARD</span> PRO</h1>
                <p className="text-muted-foreground font-mono text-[10px] uppercase tracking-[0.4em] font-bold">Heuristic Defense Matrix v4.2</p>
              </div>
           </div>

           <Card className="border-muted bg-card/50 backdrop-blur-xl shadow-2xl p-2 rounded-[2rem]">
              <CardContent className="pt-8 pb-10 px-8">
                 <form onSubmit={handleLogin} className="space-y-6">
                    <div className="space-y-2">
                       <Label className="text-[10px] font-black uppercase tracking-widest text-muted-foreground ml-1">Authentication ID</Label>
                       <div className="relative group">
                          <User className="absolute left-3.5 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground group-focus-within:text-primary transition-colors" />
                          <Input 
                            className="h-12 pl-10 bg-background/50 border-muted rounded-xl font-bold tracking-tight" 
                            placeholder="username"
                            value={loginForm.username}
                            onChange={e => setLoginForm({...loginForm, username: e.target.value})}
                            required
                          />
                       </div>
                    </div>
                    <div className="space-y-2">
                       <Label className="text-[10px] font-black uppercase tracking-widest text-muted-foreground ml-1">Secure Vector Key</Label>
                       <div className="relative group">
                          <Lock className="absolute left-3.5 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground group-focus-within:text-primary transition-colors" />
                          <Input 
                            type="password"
                            className="h-12 pl-10 bg-background/50 border-muted rounded-xl font-bold tracking-tight" 
                            placeholder="••••••••"
                            value={loginForm.password}
                            onChange={e => setLoginForm({...loginForm, password: e.target.value})}
                            required
                          />
                       </div>
                    </div>
                    {loginError && (
                      <div className="p-3 rounded-xl bg-rose-500/10 border border-rose-500/20 text-rose-500 text-[10px] font-black uppercase tracking-widest text-center animate-shake">
                         {loginError}
                      </div>
                    )}
                    <Button type="submit" className="w-full h-14 rounded-2xl font-black uppercase tracking-[0.3em] text-xs shadow-xl shadow-primary/20 hover:scale-[1.02] active:scale-[0.98] transition-all">
                       Initialize SOC Access
                    </Button>
                 </form>
              </CardContent>
              <CardFooter className="bg-muted/30 rounded-b-[1.8rem] py-6 px-8 border-t border-muted/50">
                 <div className="flex items-center justify-between w-full">
                    <div className="flex -space-x-2">
                       <div className="h-6 w-6 rounded-full border-2 border-background bg-muted flex items-center justify-center"><SiPython className="h-3 w-3" /></div>
                       <div className="h-6 w-6 rounded-full border-2 border-background bg-muted flex items-center justify-center"><SiScikitlearn className="h-3 w-3" /></div>
                       <div className="h-6 w-6 rounded-full border-2 border-background bg-muted flex items-center justify-center"><SiSqlite className="h-3 w-3" /></div>
                    </div>
                    <span className="text-[8px] font-bold text-muted-foreground uppercase tracking-widest">End-to-End Encryption Active</span>
                 </div>
              </CardFooter>
           </Card>
           
           <p className="text-center text-muted-foreground/30 text-[9px] font-bold uppercase tracking-widest">Authorized Personnel Only • Unauthorized Access Monitored</p>
        </div>
      </div>
    );
  }

  return (
    <div className="flex h-screen bg-background text-foreground overflow-hidden font-sans selection:bg-primary/30 antialiased tracking-tight perspective-[2000px]">
      <aside className={cn(
        "hidden md:flex bg-card/60 backdrop-blur-3xl border-r border-white/5 flex-col transition-all duration-700 relative z-30 shadow-[40px_0_100px_rgba(0,0,0,0.5)] overflow-hidden transform-gpu translate-z-10",
        sidebarOpen ? "w-72" : "w-24"
      )}>
        <div className="absolute top-0 -left-20 w-40 h-screen bg-primary/5 blur-[80px] pointer-events-none" />
        <div className="p-8 flex items-center justify-between">
           <div className={cn("flex items-center gap-3 transition-opacity duration-300", !sidebarOpen && "opacity-0 invisible")}>
              <div className="bg-primary p-2 rounded-xl shadow-lg shadow-primary/20">
                 <ShieldCheck className="h-5 w-5 text-white" />
              </div>
              <h1 className="font-heading font-black text-lg tracking-tighter uppercase italic whitespace-nowrap">FRAUD<span className="text-primary">GUARD</span></h1>
           </div>
           <Button variant="ghost" size="icon" className="h-8 w-8 text-muted-foreground hover:bg-muted" onClick={() => setSidebarOpen(!sidebarOpen)}>
              <Menu className="h-4 w-4" />
           </Button>
        </div>
        <nav className="flex-1 px-4 space-y-2 mt-8">
           {navItems.map(item => (
             <button 
              key={item.id} 
              onClick={() => setActiveView(item.id)}
              className={cn(
                "flex items-center gap-4 w-full px-4 py-4 rounded-2xl text-[10px] font-black uppercase tracking-[0.2em] transition-all group relative",
                activeView === item.id ? "bg-primary text-primary-foreground shadow-2xl shadow-primary/30 scale-[1.02]" : "text-muted-foreground hover:bg-muted/50 hover:text-foreground"
              )}
             >
               <item.icon className={cn("h-5 w-5 shrink-0 transition-transform group-hover:scale-110", activeView === item.id ? "text-white" : "text-primary/60")} />
               <span className={cn("transition-all duration-300 origin-left", !sidebarOpen && "opacity-0 scale-0 w-0")}>{item.label}</span>
               {activeView === item.id && (
                 <div className="absolute right-4 w-1.5 h-1.5 rounded-full bg-white shadow-[0_0_10px_white]" />
               )}
             </button>
           ))}
        </nav>
        <div className="p-6">
           <Card className={cn("bg-muted/30 border-muted-foreground/10 p-5 rounded-2xl transition-all duration-300", !sidebarOpen && "opacity-0 scale-95 h-0 overflow-hidden p-0")}>
              <div className="flex items-center gap-3 mb-4">
                 <div className="h-10 w-10 rounded-full bg-background/50 flex items-center justify-center border border-muted">
                    <User className="h-5 w-5 text-primary" />
                 </div>
                 <div className="flex-1 min-w-0">
                    <p className="text-[10px] font-black uppercase tracking-widest truncate">{user.username}</p>
                    <p className="text-[8px] font-bold text-muted-foreground uppercase opacity-60">{user.role}</p>
                 </div>
              </div>
              <Button variant="ghost" className="w-full justify-start gap-3 h-10 rounded-xl text-rose-500 hover:bg-rose-500/10 hover:text-rose-500 font-black text-[9px] uppercase tracking-widest" onClick={handleLogout}>
                 <LogOut className="h-4 w-4" /> Secure LogOut
              </Button>
           </Card>
        </div>
      </aside>

      <main className="flex-1 flex flex-col relative bg-background">
        <header className="h-20 border-b border-white/5 flex items-center justify-between px-10 relative z-20 bg-background/50 backdrop-blur-md">
           <div className="flex items-center gap-10">
              <div className="md:hidden flex items-center gap-3">
                  <Button variant="ghost" size="icon" onClick={() => setIsMobileMenuOpen(true)}>
                    <Menu className="h-6 w-6" />
                  </Button>
                  <h1 className="font-heading font-black text-lg tracking-tighter uppercase italic">FRAUD<span className="text-primary">GUARD</span></h1>
              </div>
              <div className="hidden lg:flex items-center gap-4 px-6 py-2.5 bg-muted/30 rounded-2xl border border-muted/50">
                  <div className="h-2 w-2 rounded-full bg-emerald-500 animate-pulse" />
                  <span className="text-[10px] font-black uppercase tracking-[0.2em]">Operational Status: Nominal</span>
                  <Separator orientation="vertical" className="h-4 bg-muted-foreground/20" />
                  <span className="text-[10px] font-black uppercase tracking-[0.2em] text-primary">Inference Latency: 12ms</span>
              </div>
           </div>
           <div className="flex items-center gap-4">
              <div className="relative group hidden sm:block">
                 <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                 <input className="bg-muted/40 border border-muted h-11 w-64 rounded-xl pl-10 pr-4 text-xs font-bold tracking-tight focus:outline-none focus:ring-2 focus:ring-primary/20 transition-all" placeholder="Search vectors..." />
              </div>
              <Button size="icon" className="h-11 w-11 rounded-xl bg-primary shadow-lg shadow-primary/20">
                 <Settings className="h-5 w-5 text-white" />
              </Button>
           </div>
        </header>

        <div className="flex-1 overflow-y-auto custom-scrollbar relative transform-gpu rotate-x-[0.5deg] rotate-y-[-0.5deg]">
           <div className="absolute inset-0 bg-background/95 z-0" />
           <div className="relative z-10 px-8 pb-16 transform-gpu translate-z-20">
              <div className="pt-8 transition-all duration-700">
                {activeView === 'overview' && <AnalyticsOverview isSimulating={isSimulating} onToggleSimulation={toggleSimulation} />}
                {activeView === 'prediction' && <PredictionTool />}
                {activeView === 'audit' && <TransactionAudit user={user} />}
                {activeView === 'fraud_users' && <FlaggedUsers user={user} />}
                {activeView === 'users' && <UserManagement user={user} />}
              </div>
           </div>
        </div>
      </main>

      {isMobileMenuOpen && (
        <div className="fixed inset-0 z-50 md:hidden animate-in fade-in duration-300">
           <div className="absolute inset-0 bg-background/80 backdrop-blur-sm" onClick={() => setIsMobileMenuOpen(false)} />
           <aside className="absolute top-0 left-0 bottom-0 w-4/5 max-w-sm bg-card border-r shadow-2xl p-8 slide-in-from-left duration-300 animate-in">
              <div className="flex items-center justify-between mb-12">
                 <div className="flex items-center gap-3">
                    <ShieldCheck className="h-5 w-5 text-primary" />
                    <h1 className="font-heading font-black text-lg tracking-tighter uppercase italic">FRAUD<span className="text-primary">GUARD</span> PRO</h1>
                 </div>
                 <Button variant="ghost" size="icon" onClick={() => setIsMobileMenuOpen(false)}>
                    <X className="h-6 w-6" />
                 </Button>
              </div>
              <nav className="space-y-4">
                 {navItems.map(item => (
                   <button 
                    key={item.id} 
                    onClick={() => { setActiveView(item.id); setIsMobileMenuOpen(false); }}
                    className={cn(
                      "flex items-center gap-4 w-full px-5 py-4 rounded-2xl text-xs font-black uppercase tracking-[0.2em] transition-all",
                      activeView === item.id ? "bg-primary text-primary-foreground shadow-lg shadow-primary/20" : "text-muted-foreground hover:bg-muted"
                    )}
                   >
                     <item.icon className="h-5 w-5" />
                     {item.label}
                   </button>
                 ))}
              </nav>
           </aside>
        </div>
      )}
    </div>
  );
}
