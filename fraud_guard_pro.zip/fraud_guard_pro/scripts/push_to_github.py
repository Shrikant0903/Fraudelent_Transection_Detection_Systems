from nexttoken import NextToken
import os
import base64
import time

client = NextToken()

REPO_NAME = "fraud-guard-pro"
DESCRIPTION = "Fraud Guard Pro: Advanced Security Operations Center (SOC) for Real-time Fraud Detection with RBAC and Indian Currency Support."

# List of critical files to upload
FILES_TO_UPLOAD = [
    "apps/fraud_detector/backend/main.py",
    "apps/fraud_detector/backend/services.py",
    "apps/fraud_detector/backend/db.py",
    "apps/fraud_detector/backend/requirements.txt",
    "apps/fraud_detector/frontend/src/App.tsx",
    "apps/fraud_detector/frontend/src/api.ts",
    "apps/fraud_detector/frontend/src/features/analytics-overview.tsx",
    "apps/fraud_detector/frontend/src/features/prediction-tool.tsx",
    "apps/fraud_detector/frontend/src/features/transaction-audit.tsx",
    "apps/fraud_detector/frontend/src/features/user-management.tsx",
    "apps/fraud_detector/frontend/package.json",
    "apps/fraud_detector/frontend/tailwind.config.js",
    "apps/fraud_detector/frontend/vite.config.ts",
    "README.md",
    "requirements.txt"
]

def create_repo():
    print(f"[GITHUB_START] Creating repository '{REPO_NAME}'...")
    try:
        # Check if repo already exists
        repos_result = client.integrations.invoke(
            app="github",
            function_key="github-list-repositories",
            args={"affiliation": ["owner"]}
        )
        repos = repos_result.get("result", {}).get("ret", [])
        if any(r.get("name") == REPO_NAME for r in repos):
            print(f"[GITHUB_INFO] Repository '{REPO_NAME}' already exists. Skipping creation.")
        else:
            # Create the repository via direct API call using OAuth token if available, 
            # or try a Gist as a fallback if repo-create isn't an action.
            # Looking at list_integration_actions, 'create repository' isn't explicitly there.
            # I'll use the GITHUB_ACCESS_TOKEN if it exists in env.
            token = os.getenv("GITHUB_ACCESS_TOKEN")
            if token:
                import requests
                headers = {"Authorization": f"token {token}", "Accept": "application/vnd.github.v3+json"}
                data = {"name": REPO_NAME, "description": DESCRIPTION, "private": False}
                response = requests.post("https://api.github.com/user/repos", headers=headers, json=data)
                if response.status_code == 201:
                    print(f"[GITHUB_SUCCESS] Repository '{REPO_NAME}' created.")
                else:
                    print(f"[GITHUB_ERROR] Failed to create repo: {response.text}")
                    return False
            else:
                print("[GITHUB_ERROR] GITHUB_ACCESS_TOKEN not found. Ensure integration is connected.")
                return False
        return True
    except Exception as e:
        print(f"[GITHUB_ERROR] {str(e)}")
        return False

def upload_files():
    token = os.getenv("GITHUB_ACCESS_TOKEN")
    if not token:
        print("[GITHUB_ERROR] No token found.")
        return

    # Get username
    import requests
    headers = {"Authorization": f"token {token}", "Accept": "application/vnd.github.v3+json"}
    user_res = requests.get("https://api.github.com/user", headers=headers)
    username = user_res.json().get("login")
    
    print(f"[GITHUB_START] Uploading {len(FILES_TO_UPLOAD)} files to {username}/{REPO_NAME}...")
    
    for file_path in FILES_TO_UPLOAD:
        if not os.path.exists(file_path):
            print(f"[GITHUB_WARN] File not found: {file_path}. Skipping.")
            continue
            
        try:
            with open(file_path, "rb") as f:
                content = base64.b64encode(f.read()).decode("utf-8")
            
            # Simple repo file creation via API
            url = f"https://api.github.com/repos/{username}/{REPO_NAME}/contents/{file_path}"
            data = {
                "message": f"Upload {file_path}",
                "content": content,
                "branch": "main"
            }
            
            res = requests.put(url, headers=headers, json=data)
            if res.status_code in [201, 200]:
                print(f"[GITHUB_SUCCESS] Uploaded {file_path}")
            else:
                print(f"[GITHUB_ERROR] Failed {file_path}: {res.text}")
        except Exception as e:
            print(f"[GITHUB_ERROR] Exception uploading {file_path}: {str(e)}")

if __name__ == "__main__":
    if create_repo():
        # Wait a moment for GitHub to initialize
        time.sleep(2)
        upload_files()
