from nexttoken import NextToken
import json

client = NextToken()

print("[SCRIPT_START] Checking GitHub repositories...")
try:
    result = client.integrations.invoke(
        app="github",
        function_key="github-list-repositories",
        args={"visibility": "all", "affiliation": ["owner"], "sort": "created", "direction": "desc"}
    )
    
    # Exploration showed it's result["result"]["ret"]
    action_output = result.get("result", {})
    repo_list = action_output.get("ret", [])
    
    print(f"[SCRIPT_STEP] Found {len(repo_list)} repositories.")
    
    repo_names = [repo.get("name") for repo in repo_list if isinstance(repo, dict)]
    print(f"[SCRIPT_STEP] Repositories: {repo_names}")
    
    target_exists = any("fraud-guard-pro" in name.lower() for name in repo_names)
    print(f"[SCRIPT_SUCCESS] Target repository 'fraud-guard-pro' exists: {target_exists}")

except Exception as e:
    print(f"[SCRIPT_ERROR] Failed to list repositories: {str(e)}")
