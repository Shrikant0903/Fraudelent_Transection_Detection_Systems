import React, { useState, useEffect, useCallback } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '../components/ui/card';
import { Table, TableHeader, TableBody, TableRow, TableHead, TableCell } from '../components/ui/table';
import { Badge } from '../components/ui/badge';
import { Spinner } from '../components/ui/spinner';
import { Input } from '../components/ui/input';
import { Button } from '../components/ui/button';
import { Select, SelectTrigger, SelectValue, SelectContent, SelectItem } from '../components/ui/select';
import { rpcCall, invalidateCache } from '../api';
import { cn } from '../lib/utils';
import { Search, Filter, ShieldAlert, CheckCircle2, AlertTriangle, Info, Clock, Download, RefreshCw, Upload, FileDown, AlertCircle, Database, SearchCode, History, Trash2, Flag, ToggleLeft as Toggle } from 'lucide-react';

export function TransactionAudit({ user }: { user: any }) {
  const [transactions, setTransactions] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [filter, setFilter] = useState('all');
  const [isUploading, setIsUploading] = useState(false);
  const [actionId, setActionId] = useState<number | null>(null);

  const fetchAllTransactions = useCallback(async (refresh = false) => {
    setLoading(true);
    try {
      console.log("[FETCH_START] get_transactions with filter_type:", filter);
      const data = await rpcCall({ 
        func: 'get_transactions', 
        args: { limit: 100, filter_type: filter },
        skipCache: refresh
      });
      setTransactions(data);
      console.log("[FETCH_RESPONSE] Audit data refreshed", data.length);
    } catch (err) {
      console.error("[FETCH_ERROR]", err);
    } finally {
      setLoading(false);
    }
  }, [filter]);

  useEffect(() => {
    fetchAllTransactions();
  }, [fetchAllTransactions]);

  const formatRupee = (val: number) => {
    return new Intl.NumberFormat('en-IN', {
      style: 'currency',
      currency: 'INR',
      maximumFractionDigits: 0
    }).format(val);
  };

  const handleDelete = async (tx_id: number) => {
    if (!window.confirm("Are you sure you want to permanently delete this forensic record? This action is irreversible.")) return;
    
    setActionId(tx_id);
    try {
      await rpcCall({ func: 'remove_transaction', args: { tx_id } });
      invalidateCache(['get_transactions', 'get_analytics']);
      await fetchAllTransactions(true);
    } catch (err) {
      console.error("[DELETE_ERROR]", err);
    } finally {
      setActionId(null);
    }
  };

  const handleToggleFlag = async (tx_id: number, currentFlag: boolean) => {
    setActionId(tx_id);
    try {
      const updated = await rpcCall({ func: 'toggle_transaction_flag', args: { tx_id, flagged: !currentFlag } });
      setTransactions(prev => prev.map(t => t.id === tx_id ? updated : t));
      invalidateCache(['get_transactions', 'get_analytics']);
    } catch (err) {
      console.error("[FLAG_ERROR]", err);
    } finally {
      setActionId(null);
    }
  };

  const handleFileUpload = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    setIsUploading(true);
    const reader = new FileReader();
    reader.onload = async (e) => {
      try {
        const text = e.target?.result as string;
        const lines = text.split('\n');
        const headers = lines[0].split(',').map(h => h.trim());
        
        const data = lines.slice(1).filter(l => l.trim()).map(line => {
          const values = line.split(',').map(v => v.trim());
          const obj: any = {};
          headers.forEach((h, i) => {
            const val = values[i];
            obj[h] = isNaN(Number(val)) ? val : Number(val);
          });
          return obj;
        });

        console.log("[CSV_UPLOAD] Processing records:", data.length);
        const results = await rpcCall({ func: 'predict_batch', args: { transactions: data } });
        console.log("[CSV_UPLOAD_SUCCESS] Batch results:", results.length);
        await fetchAllTransactions();
      } catch (err) {
        console.error("[CSV_UPLOAD_ERROR]", err);
        alert("Failed to process CSV. Ensure headers match model requirements.");
      } finally {
        setIsUploading(false);
      }
    };
    reader.readAsText(file);
  };

  const downloadResults = () => {
    if (transactions.length === 0) return;
    const headers = Object.keys(transactions[0]);
    const csvContent = [
      headers.join(','),
      ...transactions.map(row => headers.map(h => {
        const val = row[h];
        return typeof val === 'string' && val.includes(',') ? `"${val}"` : val;
      }).join(','))
    ].join('\n');
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.setAttribute("href", url);
    link.setAttribute("download", `sentry_audit_report_${new Date().toISOString().slice(0,10)}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const filteredData = transactions.filter(tx => 
    tx.user_id.toLowerCase().includes(search.toLowerCase()) ||
    tx.type.toLowerCase().includes(search.toLowerCase()) ||
    tx.risk_level.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-700">
      <div className="flex flex-col xl:flex-row xl:items-center justify-between gap-6">
        <div className="flex items-center gap-4">
           <div className="h-12 w-12 rounded-2xl bg-primary/10 flex items-center justify-center border border-primary/20 shadow-lg shadow-primary/5">
              <History className="h-6 w-6 text-primary" />
           </div>
           <div>
             <h2 className="font-heading text-2xl font-black tracking-tighter uppercase italic">Forensic Archive</h2>
             <p className="text-muted-foreground text-xs font-bold uppercase tracking-widest opacity-60">Complete audit trail of processed vectors and model inferences</p>
           </div>
        </div>
        <div className="flex flex-wrap items-center gap-3">
           <div className="relative group">
             <input type="file" accept=".csv" className="absolute inset-0 w-full h-full opacity-0 cursor-pointer z-10" onChange={handleFileUpload} disabled={isUploading} />
             <Button variant="outline" className="gap-2 h-11 px-6 font-black uppercase tracking-[0.15em] text-[10px] border-muted hover:bg-primary hover:text-white transition-all">
               {isUploading ? <Spinner className="h-4 w-4" /> : <Upload className="h-4 w-4" />}
               Bulk Ingest (.CSV)
             </Button>
           </div>
           <Button variant="outline" className="gap-2 h-11 px-6 font-black uppercase tracking-[0.15em] text-[10px] border-muted hover:bg-muted" onClick={() => fetchAllTransactions()}>
             <RefreshCw className={cn("h-4 w-4", loading && "animate-spin")} />
             Sync Archive
           </Button>
           <Button variant="default" className="gap-2 h-11 px-6 font-black uppercase tracking-[0.15em] text-[10px] shadow-lg shadow-primary/20" onClick={downloadResults}>
             <FileDown className="h-4 w-4" />
             Export Audit Report
           </Button>
        </div>
      </div>

      <Card className="border-muted shadow-2xl overflow-hidden bg-card/30 backdrop-blur-md">
        <CardHeader className="bg-muted/10 pb-8 pt-8 border-b border-muted px-8">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
            <div className="relative flex-1 max-w-md group">
              <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground group-focus-within:text-primary transition-colors" />
              <Input 
                placeholder="Search Archive by Vector ID or User..." 
                className="pl-10 h-12 bg-background/50 border-muted font-bold tracking-tight text-xs" 
                value={search}
                onChange={e => setSearch(e.target.value)}
              />
            </div>
            <div className="flex items-center gap-3">
              <div className="flex items-center gap-2 bg-muted/40 rounded-xl px-4 py-2 border border-muted/50 h-12">
                <Filter className="h-4 w-4 text-primary" />
                <span className="text-[10px] font-black uppercase tracking-widest text-muted-foreground">Log Filter:</span>
              </div>
              <Select value={filter} onValueChange={setFilter}>
                <SelectTrigger className="w-48 bg-background h-12 font-black uppercase tracking-widest text-[10px] border-muted shadow-sm focus:ring-primary/20"><SelectValue /></SelectTrigger>
                <SelectContent className="bg-popover border-muted">
                  <SelectItem value="all" className="font-black text-[10px] uppercase tracking-widest">SHOW_ALL</SelectItem>
                  <SelectItem value="flagged" className="font-black text-[10px] uppercase tracking-widest text-rose-500">FLAGGED_ONLY</SelectItem>
                  <SelectItem value="non-flagged" className="font-black text-[10px] uppercase tracking-widest text-emerald-500">CLEAN_ONLY</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        </CardHeader>
        <CardContent className="p-0">
          <Table>
            <TableHeader className="bg-muted/30">
              <TableRow className="hover:bg-transparent border-none">
                <TableHead className="font-black uppercase tracking-[0.2em] text-[9px] h-14 px-8">Cycle / Origin</TableHead>
                <TableHead className="font-black uppercase tracking-[0.2em] text-[9px]">Transmission Set</TableHead>
                <TableHead className="font-black uppercase tracking-[0.2em] text-[9px]">Differential Balance</TableHead>
                <TableHead className="font-black uppercase tracking-[0.2em] text-[9px]">Risk Level</TableHead>
                <TableHead className="font-black uppercase tracking-[0.2em] text-[9px]">Clearance</TableHead>
                <TableHead className="text-right font-black uppercase tracking-[0.2em] text-[9px] px-8">Audit Control</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {loading ? (
                <TableRow>
                  <TableCell colSpan={6} className="h-96 text-center">
                    <div className="flex flex-col items-center justify-center space-y-6">
                      <div className="relative">
                         <div className="absolute inset-0 bg-primary/20 rounded-full blur-xl animate-pulse" />
                         <Spinner className="h-10 w-10 text-primary relative z-10" />
                      </div>
                      <p className="text-xs text-muted-foreground animate-pulse uppercase tracking-[0.3em] font-black italic">Deciphering forensic records...</p>
                    </div>
                  </TableCell>
                </TableRow>
              ) : filteredData.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={6} className="h-96 text-center">
                    <div className="flex flex-col items-center justify-center space-y-4">
                      <div className="p-8 rounded-3xl bg-muted/20 border border-muted border-dashed group-hover:scale-110 transition-transform duration-500">
                        <SearchCode className="h-12 w-12 text-muted-foreground/20" />
                      </div>
                      <div className="space-y-1">
                        <p className="text-sm font-black text-muted-foreground uppercase tracking-widest">Zero Forensic Hits</p>
                        <p className="text-[10px] text-muted-foreground/60 uppercase tracking-tighter">Adjust filters or ingestion source</p>
                      </div>
                    </div>
                  </TableCell>
                </TableRow>
              ) : (
                filteredData.map((tx) => (
                  <TableRow key={tx.id} className={cn("transition-all group border-b border-muted/20", (tx.flagged || tx.prediction === 'FRAUD') ? "bg-rose-500/[0.08] hover:bg-rose-500/[0.12]" : "hover:bg-muted/40")}>
                    <TableCell className="py-6 px-8">
                      <div className="flex flex-col">
                        <span className="font-mono text-[10px] font-black text-primary/70">#{tx.id.toString().padStart(8, '0')}</span>
                        <div className="flex items-center gap-1.5 mt-1 text-[10px] font-bold text-muted-foreground/60 uppercase tracking-tighter">
                          <Clock className="h-3 w-3" />
                          {new Date(tx.timestamp).toLocaleString()}
                        </div>
                      </div>
                    </TableCell>
                    <TableCell>
                      <div className="flex flex-col">
                        <span className="font-black text-xs tracking-tight uppercase italic">{tx.user_id}</span>
                        <div className="flex items-center gap-1.5 mt-1.5">
                           <Badge variant="secondary" className="text-[8px] font-black h-4 px-1 border-none bg-primary/10 text-primary uppercase tracking-widest">{tx.type}</Badge>
                           <span className="text-xs font-black tracking-tighter">{formatRupee(tx.amount)}</span>
                        </div>
                      </div>
                    </TableCell>
                    <TableCell>
                      <div className="flex flex-col gap-1.5">
                        <div className="flex items-center gap-2">
                           <span className="text-[9px] font-black text-muted-foreground uppercase">Delta:</span>
                           <span className="text-[10px] font-mono font-bold text-muted-foreground">{formatRupee(tx.oldbalanceOrg - tx.newbalanceOrig)}</span>
                        </div>
                        <div className="h-1 w-32 bg-muted/50 rounded-full overflow-hidden">
                           <div className="h-full bg-muted-foreground/20" style={{ width: tx.amount > tx.oldbalanceOrg ? '100%' : `${(tx.amount/tx.oldbalanceOrg)*100}%` }} />
                        </div>
                      </div>
                    </TableCell>
                    <TableCell>
                      <div className="space-y-2 max-w-[140px]">
                        <div className="flex items-center justify-between">
                           <Badge variant={tx.risk_level === 'High' || tx.risk_level === 'Medium' ? 'destructive' : 'outline'} className={cn(
                             "text-[9px] uppercase font-black h-4 px-1.5 border-none",
                             tx.risk_level === 'High' ? "bg-rose-500 text-white animate-pulse" : "bg-muted text-muted-foreground"
                           )}>
                             {tx.risk_level}
                           </Badge>
                           <span className="text-[10px] font-mono font-black italic">{(tx.confidence * 100).toFixed(1)}%</span>
                        </div>
                        <div className="w-full bg-muted/40 h-1 rounded-full overflow-hidden border border-white/5 shadow-inner">
                          <div 
                            className={cn(
                              "h-full rounded-full transition-all duration-1000",
                              tx.confidence > 0.8 ? "bg-rose-500" : tx.confidence > 0.5 ? "bg-amber-500" : "bg-emerald-500"
                            )} 
                            style={{ width: `${tx.confidence * 100}%` }}
                          />
                        </div>
                      </div>
                    </TableCell>
                    <TableCell>
                      {tx.prediction === 'FRAUD' ? (
                        <div className="flex flex-col gap-1">
                          <div className="flex items-center gap-2 text-rose-500">
                            <div className="h-2 w-2 rounded-full bg-rose-500 animate-ping" />
                            <span className="text-[9px] font-black uppercase tracking-widest">⚠️ Fraud Detected</span>
                          </div>
                          <p className="text-[8px] font-mono font-bold text-rose-500/60 uppercase">Interdiction Active</p>
                        </div>
                      ) : (
                        <div className="flex items-center gap-2 text-emerald-500 opacity-60">
                          <CheckCircle2 className="h-3.5 w-3.5" />
                          <span className="text-[9px] font-black uppercase tracking-widest">VERIFIED</span>
                        </div>
                      )}
                    </TableCell>
                    <TableCell className="text-right px-8">
                       <div className="flex items-center justify-end gap-2">
                          <Button 
                            variant="ghost" 
                            size="icon" 
                            className={cn(
                              "h-9 w-9 rounded-xl transition-all", 
                              tx.flagged ? "text-rose-500 hover:bg-rose-500/20" : "text-muted-foreground hover:bg-primary/20 hover:text-primary"
                            )}
                            onClick={() => handleToggleFlag(tx.id, tx.flagged)}
                            disabled={actionId === tx.id}
                          >
                             {actionId === tx.id ? <Spinner className="h-4 w-4" /> : <Flag className={cn("h-4 w-4", tx.flagged && "fill-current")} />}
                          </Button>
                          {user.role === 'admin' && (
                             <Button 
                               variant="ghost" 
                               size="icon" 
                               className="h-9 w-9 rounded-xl text-muted-foreground hover:bg-rose-500/20 hover:text-rose-500 transition-all"
                               onClick={() => handleDelete(tx.id)}
                               disabled={actionId === tx.id}
                             >
                                {actionId === tx.id ? <Spinner className="h-4 w-4" /> : <Trash2 className="h-4 w-4" />}
                             </Button>
                          )}
                       </div>
                    </TableCell>
                  </TableRow>
                ))
              )}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  );
}
