import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from '../components/ui/card';
import { Input } from '../components/ui/input';
import { Button } from '../components/ui/button';
import { Select, SelectTrigger, SelectValue, SelectContent, SelectItem } from '../components/ui/select';
import { Badge } from '../components/ui/badge';
import { Label } from '../components/ui/label';
import { Spinner } from '../components/ui/spinner';
import { Tabs, TabsList, TabsTrigger, TabsContent } from '../components/ui/tabs';
import { Table, TableHeader, TableBody, TableRow, TableHead, TableCell } from '../components/ui/table';
import { rpcCall, invalidateCache } from '../api';
import { cn } from '../lib/utils';
import { AlertCircle, CheckCircle, ShieldAlert, Zap, ArrowRight, BrainCircuit, BarChartHorizontal, FileText, Share2, Printer, Upload, FileDown, CheckCircle2 } from 'lucide-react';

export function PredictionTool() {
  const [formData, setFormData] = useState({
    user_id: 'U' + Math.floor(Math.random() * 90000 + 10000),
    type: 'TRANSFER',
    amount: 15000,
    oldbalanceOrg: 50000,
    newbalanceOrig: 35000,
    oldbalanceDest: 0,
    newbalanceDest: 15000
  });

  const [prediction, setPrediction] = useState<any>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [bulkData, setBulkData] = useState<any[]>([]);
  const [bulkResults, setBulkResults] = useState<any[]>([]);
  const [isProcessingBulk, setIsProcessingBulk] = useState(false);

  const formatRupee = (val: number) => {
    return new Intl.NumberFormat('en-IN', {
      style: 'currency',
      currency: 'INR',
      maximumFractionDigits: 0
    }).format(val);
  };

  const handlePredict = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError(null);
    setPrediction(null);
    try {
      const result = await rpcCall({ 
        func: 'predict_transaction', 
        args: {
          user_id: formData.user_id,
          type: formData.type,
          amount: Number(formData.amount),
          oldbalanceOrg: Number(formData.oldbalanceOrg),
          newbalanceOrig: Number(formData.newbalanceOrig),
          oldbalanceDest: Number(formData.oldbalanceDest),
          newbalanceDest: Number(formData.newbalanceDest)
        } 
      });
      setPrediction(result);
      invalidateCache(['get_transactions', 'get_analytics', 'get_fraud_users']);
    } catch (err: any) {
      setError(err.message || 'Prediction analysis failed');
    } finally {
      setLoading(false);
    }
  };

  const handleFileUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (e) => {
      try {
        const text = e.target?.result as string;
        const lines = text.split('\n');
        const headers = lines[0].split(',').map(h => h.trim());
        const data = lines.slice(1).filter(l => l.trim()).map(line => {
          const values = line.split(',').map(v => v.trim());
          const obj: any = {};
          headers.forEach((h, i) => {
            const val = values[i];
            obj[h] = isNaN(Number(val)) ? val : Number(val);
          });
          return obj;
        });
        setBulkData(data);
        setBulkResults([]);
      } catch (err) {
        alert("Failed to parse CSV. Check formatting.");
      }
    };
    reader.readAsText(file);
  };

  const processBulk = async () => {
    setIsProcessingBulk(true);
    try {
      const results = await rpcCall({ func: 'predict_batch', args: { transactions: bulkData } });
      setBulkResults(results);
      invalidateCache(['get_transactions', 'get_analytics', 'get_fraud_users']);
    } catch (err) {
      alert("Bulk processing failed.");
    } finally {
      setIsProcessingBulk(false);
    }
  };

  const downloadResults = () => {
    if (bulkResults.length === 0) return;
    const headers = Object.keys(bulkResults[0]);
    const csvContent = [
      headers.join(','),
      ...bulkResults.map(row => headers.map(h => row[h]).join(','))
    ].join('\n');
    const blob = new Blob([csvContent], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = `fraudguard_bulk_results.csv`;
    link.click();
  };

  const getCounterMeasure = (pred: string) => {
    if (pred === 'FRAUD') {
      return (
        <div className="space-y-2">
           <p className="text-rose-500 font-black italic">DENY ACCESS & INTERDICT</p>
           <ul className="text-[10px] text-rose-500/70 space-y-1">
              <li>• Automated lockout triggered</li>
              <li>• Notify financial forensic unit</li>
              <li>• Freeze source account (Orig_ID)</li>
           </ul>
        </div>
      );
    }
    return (
      <div className="space-y-2">
         <p className="text-emerald-500 font-black italic">PROCEED & VALIDATE</p>
         <ul className="text-[10px] text-emerald-500/70 space-y-1">
            <li>• Record behavioral signature</li>
            <li>• Standard compliance check OK</li>
            <li>• Authorize transmission</li>
         </ul>
      </div>
    );
  };

  return (
    <div className="max-w-7xl mx-auto py-4 animate-in fade-in slide-in-from-bottom-4 duration-700">
      <Tabs defaultValue="single" className="space-y-8">
        <div className="flex items-center justify-center">
          <TabsList className="bg-muted/30 border border-muted p-1 rounded-2xl h-14 w-full max-w-md">
            <TabsTrigger value="single" className="rounded-xl font-black uppercase tracking-widest text-[10px] data-[state=active]:bg-primary data-[state=active]:text-white h-full flex-1">
              Single Transaction
            </TabsTrigger>
            <TabsTrigger value="bulk" className="rounded-xl font-black uppercase tracking-widest text-[10px] data-[state=active]:bg-primary data-[state=active]:text-white h-full flex-1">
              Bulk Processing
            </TabsTrigger>
          </TabsList>
        </div>

        <TabsContent value="single" className="m-0">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            <Card className="shadow-2xl border-primary/20 bg-muted/30 backdrop-blur-sm overflow-hidden flex flex-col">
              <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-primary/50 via-primary to-primary/50" />
              <CardHeader className="pb-8">
                <div className="flex items-center gap-4">
                  <div className="rounded-xl bg-primary/10 p-3 border border-primary/20 shadow-[0_0_15px_rgba(var(--primary-rgb),0.1)]">
                    <BrainCircuit className="h-6 w-6 text-primary" />
                  </div>
                  <div>
                    <CardTitle className="font-heading text-xl font-black tracking-tight uppercase italic text-primary">FraudGuard Pro</CardTitle>
                    <CardDescription className="font-mono text-[10px] uppercase tracking-widest font-bold text-muted-foreground/60">Real-time model inference for single vectors</CardDescription>
                  </div>
                </div>
              </CardHeader>
              <form onSubmit={handlePredict} className="flex-1 flex flex-col">
                <CardContent className="space-y-6 flex-1">
                  <div className="grid grid-cols-2 gap-6">
                    <div className="space-y-2">
                      <Label htmlFor="user_id" className="text-[10px] font-bold uppercase tracking-widest text-muted-foreground">Entity Identifier</Label>
                      <Input id="user_id" className="font-mono text-sm h-11 bg-background/50 border-muted" value={formData.user_id} onChange={e => setFormData({...formData, user_id: e.target.value})} placeholder="U-XXXXX" required />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="type" className="text-[10px] font-bold uppercase tracking-widest text-muted-foreground">Transaction Vector</Label>
                      <Select value={formData.type} onValueChange={v => setFormData({...formData, type: v})}>
                        <SelectTrigger id="type" className="h-11 font-bold tracking-widest bg-background/50 border-muted text-xs"><SelectValue /></SelectTrigger>
                        <SelectContent>
                          {['PAYMENT', 'TRANSFER', 'CASH_OUT', 'DEBIT', 'CASH_IN'].map(t => (
                            <SelectItem key={t} value={t} className="text-xs font-bold tracking-widest">{t}</SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="amount" className="text-[10px] font-bold uppercase tracking-widest text-muted-foreground">Transaction Magnitude (₹)</Label>
                    <div className="relative group">
                      <div className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground group-focus-within:text-primary transition-colors font-bold text-sm">₹</div>
                      <Input id="amount" type="number" step="1" className="pl-7 font-heading text-lg font-bold h-12 bg-background/50 border-muted" value={formData.amount} onChange={e => setFormData({...formData, amount: Number(e.target.value)})} required />
                    </div>
                  </div>

                  <div className="p-6 rounded-2xl bg-muted/50 border border-muted-foreground/10 space-y-6">
                     <div className="flex items-center gap-2 border-b border-muted pb-3 mb-2">
                        <div className="h-1 w-4 rounded-full bg-primary" />
                        <span className="text-[10px] font-black uppercase tracking-[0.2em]">Balance Differential Matrix</span>
                     </div>
                     <div className="grid grid-cols-2 gap-6">
                        <div className="space-y-2">
                          <Label className="text-[9px] font-bold uppercase text-muted-foreground">Origin Pre-TX (₹)</Label>
                          <Input type="number" step="1" className="font-mono text-xs bg-background h-10 border-muted" value={formData.oldbalanceOrg} onChange={e => setFormData({...formData, oldbalanceOrg: Number(e.target.value)})} />
                        </div>
                        <div className="space-y-2">
                          <Label className="text-[9px] font-bold uppercase text-muted-foreground">Origin Post-TX (₹)</Label>
                          <Input type="number" step="1" className="font-mono text-xs bg-background h-10 border-muted" value={formData.newbalanceOrig} onChange={e => setFormData({...formData, newbalanceOrig: Number(e.target.value)})} />
                        </div>
                     </div>
                     <div className="grid grid-cols-2 gap-6">
                        <div className="space-y-2">
                          <Label className="text-[9px] font-bold uppercase text-muted-foreground">Dest Pre-TX (₹)</Label>
                          <Input type="number" step="1" className="font-mono text-xs bg-background h-10 border-muted" value={formData.oldbalanceDest} onChange={e => setFormData({...formData, oldbalanceDest: Number(e.target.value)})} />
                        </div>
                        <div className="space-y-2">
                          <Label className="text-[9px] font-bold uppercase text-muted-foreground">Dest Post-TX (₹)</Label>
                          <Input type="number" step="1" className="font-mono text-xs bg-background h-10 border-muted" value={formData.newbalanceDest} onChange={e => setFormData({...formData, newbalanceDest: Number(e.target.value)})} />
                        </div>
                     </div>
                  </div>
                </CardContent>
                <CardFooter className="flex-col items-stretch gap-4 pb-8">
                  <Button type="submit" className="w-full gap-3 font-black uppercase tracking-[0.2em] h-14 text-sm shadow-[0_0_30px_rgba(var(--primary-rgb),0.2)] hover:shadow-[0_0_40px_rgba(var(--primary-rgb),0.3)] transition-all active:scale-[0.98]" disabled={loading}>
                    {loading ? <Spinner className="h-5 w-5" /> : <Zap className="h-5 w-5 fill-current" />}
                    {loading ? "Inference in Progress..." : "Run Prediction"}
                  </Button>
                  {error && (
                    <div className="flex items-center justify-center gap-2 p-3 rounded-lg bg-rose-500/10 border border-rose-500/20 text-rose-500 text-xs font-bold uppercase tracking-widest">
                      <AlertCircle className="h-4 w-4" /> {error}
                    </div>
                  )}
                </CardFooter>
              </form>
            </Card>

            <div className="space-y-6">
              {prediction ? (
                <div className="h-full animate-in zoom-in-95 fade-in duration-1000">
                  <Card className={cn(
                    "h-full border-2 transition-all duration-1000 overflow-hidden relative group",
                    prediction.prediction === 'FRAUD' ? "border-rose-500 bg-rose-500/[0.03] shadow-[0_0_50px_rgba(244,63,94,0.1)]" : "border-emerald-500 bg-emerald-500/[0.03] shadow-[0_0_50px_rgba(16,185,129,0.1)]"
                  )}>
                    <CardHeader className="text-center pb-8 pt-10">
                      <div className="mx-auto mb-6 p-6 rounded-2xl bg-background/80 border border-muted shadow-2xl w-fit relative">
                        {prediction.prediction === 'FRAUD' ? 
                          <ShieldAlert className="h-12 w-12 text-rose-500 animate-pulse" /> : 
                          <CheckCircle className="h-12 w-12 text-emerald-500" />
                        }
                      </div>
                      <CardTitle className={cn(
                        "text-4xl font-heading font-black uppercase tracking-[0.2em] italic",
                        prediction.prediction === 'FRAUD' ? "text-rose-500 drop-shadow-[0_0_10px_rgba(244,63,94,0.3)]" : "text-emerald-500"
                      )}>
                        {prediction.prediction}
                      </CardTitle>
                      {prediction.warning && (
                        <Badge variant="outline" className="mt-4 bg-rose-500/10 text-rose-500 border-rose-500/20 font-black animate-bounce">
                           {prediction.warning}
                        </Badge>
                      )}
                    </CardHeader>
                    
                    <CardContent className="space-y-8 px-8">
                      <div className="grid grid-cols-2 gap-4">
                        <div className="bg-background/60 p-5 rounded-2xl border border-muted shadow-sm hover:border-primary/20 transition-colors">
                          <p className="text-[9px] text-muted-foreground font-black uppercase tracking-widest mb-2">Risk Level</p>
                          <p className={cn(
                            "text-lg font-black font-heading italic uppercase tracking-tight",
                            prediction.risk_level === 'High' ? "text-rose-500" : prediction.risk_level === 'Medium' ? "text-amber-500" : "text-emerald-500"
                          )}>{prediction.risk_level}</p>
                        </div>
                        <div className="bg-background/60 p-5 rounded-2xl border border-muted shadow-sm hover:border-primary/20 transition-colors">
                          <p className="text-[9px] text-muted-foreground font-black uppercase tracking-widest mb-2">Counter Measure</p>
                          <div className="text-sm">
                            {getCounterMeasure(prediction.prediction)}
                          </div>
                        </div>
                      </div>

                      <div className="bg-muted/40 p-6 rounded-2xl border border-dashed border-muted-foreground/20">
                        <div className="flex items-center gap-2 mb-3">
                          <div className="h-1.5 w-1.5 rounded-full bg-primary" />
                          <span className="text-[10px] font-black uppercase tracking-[0.2em] text-muted-foreground">Forensic Breakdown</span>
                        </div>
                        <p className="text-xs text-muted-foreground leading-relaxed font-medium italic">
                          "Transaction vector {prediction.type} analyzed for entity {prediction.user_id}. Differential delta of {formatRupee(prediction.amount)} validated against persistent fraud patterns."
                        </p>
                      </div>
                    </CardContent>
                    
                    <CardFooter className="flex gap-3 px-8 pb-10 pt-4">
                       <Button variant="outline" className="flex-1 text-[10px] font-bold uppercase tracking-widest h-10 gap-2 border-muted hover:bg-muted" onClick={() => window.print()}>
                          <Printer className="h-3.5 w-3.5" /> Print Audit
                       </Button>
                       <Button variant="outline" className="flex-1 text-[10px] font-bold uppercase tracking-widest h-10 gap-2 border-muted hover:bg-muted">
                          <Share2 className="h-3.5 w-3.5" /> Export Case
                       </Button>
                    </CardFooter>
                  </Card>
                </div>
              ) : (
                <div className="h-full flex flex-col items-center justify-center p-12 text-center border-2 border-dashed border-muted rounded-2xl space-y-6 bg-muted/5">
                  <BarChartHorizontal className="h-16 w-16 text-muted-foreground/20" />
                  <p className="text-xs text-muted-foreground/60 max-w-xs mx-auto font-medium">Input transaction features and run prediction to view risk assessment.</p>
                </div>
              )}
            </div>
          </div>
        </TabsContent>

        <TabsContent value="bulk" className="m-0 space-y-6">
           <div className="flex items-center justify-between">
              <div className="flex items-center gap-4">
                <div className="h-10 w-10 rounded-xl bg-primary/10 flex items-center justify-center border border-primary/20">
                  <Upload className="h-5 w-5 text-primary" />
                </div>
                <div>
                   <h3 className="font-heading font-black tracking-tighter uppercase italic">Bulk Ingestion Module</h3>
                   <p className="text-[10px] text-muted-foreground font-bold uppercase tracking-widest opacity-60">Upload CSV dataset for batch vectorization</p>
                </div>
              </div>
              <div className="flex items-center gap-3">
                 <div className="relative">
                    <input type="file" accept=".csv" className="absolute inset-0 w-full h-full opacity-0 cursor-pointer z-10" onChange={handleFileUpload} />
                    <Button variant="outline" className="h-11 px-6 font-black uppercase tracking-widest text-[10px] border-muted hover:bg-muted">
                       Select CSV File
                    </Button>
                 </div>
                 {bulkData.length > 0 && (
                   <Button variant="default" className="h-11 px-6 font-black uppercase tracking-widest text-[10px] shadow-lg shadow-primary/20" onClick={processBulk} disabled={isProcessingBulk}>
                     {isProcessingBulk ? <Spinner className="h-4 w-4 mr-2" /> : <Zap className="h-4 w-4 mr-2 fill-current" />}
                     Predict Transactions
                   </Button>
                 )}
                 {bulkResults.length > 0 && (
                   <Button variant="outline" className="h-11 px-6 font-black uppercase tracking-widest text-[10px] text-emerald-500 border-emerald-500/20 hover:bg-emerald-500 hover:text-white" onClick={downloadResults}>
                      <FileDown className="h-4 w-4 mr-2" />
                      Download Results CSV
                   </Button>
                 )}
              </div>
           </div>

           {bulkData.length > 0 ? (
             <Card className="border-muted shadow-2xl overflow-hidden bg-muted/10 backdrop-blur-md">
               <CardHeader className="border-b border-muted bg-muted/20 px-8 py-6">
                  <div className="flex items-center justify-between">
                     <span className="text-[10px] font-black uppercase tracking-widest text-muted-foreground">Data Preview ({bulkResults.length > 0 ? 'RESULTS' : 'STAGED'}): {bulkData.length} Records</span>
                     {bulkResults.length > 0 && <Badge className="bg-emerald-500 font-black text-[9px]">COMPLETE</Badge>}
                  </div>
               </CardHeader>
               <CardContent className="p-0 max-h-[500px] overflow-y-auto custom-scrollbar">
                 <Table>
                   <TableHeader className="bg-muted/30 sticky top-0 z-20">
                     <TableRow className="border-none">
                       <TableHead className="font-black uppercase tracking-widest text-[9px] h-12 px-8">User ID</TableHead>
                       <TableHead className="font-black uppercase tracking-widest text-[9px]">Type</TableHead>
                       <TableHead className="font-black uppercase tracking-widest text-[9px]">Amount</TableHead>
                       <TableHead className="font-black uppercase tracking-widest text-[9px]">Status</TableHead>
                       <TableHead className="font-black uppercase tracking-widest text-[9px]">Risk Level</TableHead>
                       <TableHead className="font-black uppercase tracking-widest text-[9px] px-8">Action</TableHead>
                     </TableRow>
                   </TableHeader>
                   <TableBody>
                      {(bulkResults.length > 0 ? bulkResults : bulkData).map((row, i) => (
                        <TableRow key={i} className={cn("border-b border-muted/20", row.prediction === 'FRAUD' && "bg-rose-500/5")}>
                          <TableCell className="font-black px-8 italic">{row.user_id}</TableCell>
                          <TableCell><Badge variant="outline" className="font-black text-[9px] border-muted">{row.type}</Badge></TableCell>
                          <TableCell className="font-mono text-xs">{formatRupee(row.amount)}</TableCell>
                          <TableCell>
                             {row.prediction ? (
                               <Badge className={cn("font-black text-[9px]", row.prediction === 'FRAUD' ? "bg-rose-500" : "bg-emerald-500")}>
                                  {row.prediction}
                               </Badge>
                             ) : <span className="text-[9px] font-bold text-muted-foreground italic">AWAITING_INFERENCE</span>}
                          </TableCell>
                          <TableCell>
                             {row.risk_level ? (
                               <span className={cn("font-black text-[10px] uppercase italic", row.risk_level === 'High' ? "text-rose-500" : row.risk_level === 'Medium' ? "text-amber-500" : "text-emerald-500")}>
                                 {row.risk_level}
                               </span>
                             ) : '—'}
                          </TableCell>
                          <TableCell className="px-8 italic text-[10px] font-bold text-muted-foreground">
                             {row.prediction === 'FRAUD' ? 'DENY' : row.prediction === 'GENUINE' ? 'PASS' : 'PENDING'}
                          </TableCell>
                        </TableRow>
                      ))}
                   </TableBody>
                 </Table>
               </CardContent>
             </Card>
           ) : (
             <div className="h-64 flex flex-col items-center justify-center border-2 border-dashed border-muted rounded-2xl bg-muted/5">
                <FileText className="h-12 w-12 text-muted-foreground/20 mb-4" />
                <p className="text-[10px] font-black text-muted-foreground uppercase tracking-widest">No bulk data staged for analysis</p>
             </div>
           )}
        </TabsContent>
      </Tabs>
    </div>
  );
}
