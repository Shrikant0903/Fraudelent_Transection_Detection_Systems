import React, { useState, useEffect, useCallback } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '../components/ui/card';
import { Table, TableHeader, TableBody, TableRow, TableHead, TableCell } from '../components/ui/table';
import { Badge } from '../components/ui/badge';
import { Spinner } from '../components/ui/spinner';
import { Button } from '../components/ui/button';
import { rpcCall, invalidateCache } from '../api';
import { cn } from '../lib/utils';
import { ShieldAlert, UserX, UserCheck, RefreshCw, Trash2, Clock, AlertTriangle } from 'lucide-react';

export function FlaggedUsers({ user }: { user: any }) {
  const [fraudUsers, setFraudUsers] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [actionId, setActionId] = useState<string | null>(null);

  const fetchFraudUsers = useCallback(async () => {
    setLoading(true);
    try {
      console.log("[FETCH_START] get_fraud_users");
      const data = await rpcCall({ func: 'get_fraud_users' });
      setFraudUsers(data);
      console.log("[FETCH_RESPONSE] Fraud users data refreshed", data.length);
    } catch (err) {
      console.error("[FETCH_ERROR]", err);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchFraudUsers();
  }, [fetchFraudUsers]);

  const handleUnflag = async (user_id: string) => {
    if (user.role !== 'admin') {
      alert("Unauthorized: Admin access required to unflag users.");
      return;
    }
    
    if (!window.confirm(`Are you sure you want to unflag user ${user_id}? This will remove them from the permanent fraud watch list.`)) return;

    setActionId(user_id);
    try {
      await rpcCall({ func: 'unflag_user', args: { user_id } });
      setFraudUsers(prev => prev.filter(u => u.user_id !== user_id));
      invalidateCache(['get_fraud_users', 'get_transactions', 'get_analytics']);
    } catch (err) {
      console.error("[UNFLAG_ERROR]", err);
    } finally {
      setActionId(null);
    }
  };

  return (
    <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-700">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-4">
           <div className="h-12 w-12 rounded-2xl bg-rose-500/10 flex items-center justify-center border border-rose-500/20 shadow-lg shadow-rose-500/5">
              <ShieldAlert className="h-6 w-6 text-rose-500" />
           </div>
           <div>
             <h2 className="font-heading text-2xl font-black tracking-tighter uppercase italic">Flagged Fraud Users</h2>
             <p className="text-muted-foreground text-xs font-bold uppercase tracking-widest opacity-60">Permanent interdiction list for confirmed fraud entities</p>
           </div>
        </div>
        <Button variant="outline" className="gap-2 h-11 px-6 font-black uppercase tracking-[0.15em] text-[10px] border-muted hover:bg-muted" onClick={fetchFraudUsers}>
          <RefreshCw className={cn("h-4 w-4", loading && "animate-spin")} />
          Sync Registry
        </Button>
      </div>

      <Card className="border-rose-500/20 shadow-2xl overflow-hidden bg-card/30 backdrop-blur-md relative">
        <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-rose-500/50 via-rose-500 to-rose-500/50" />
        <CardHeader className="bg-rose-500/5 pb-8 pt-8 border-b border-rose-500/10 px-8">
          <div className="flex items-center gap-3">
             <AlertTriangle className="h-5 w-5 text-rose-500" />
             <span className="text-[10px] font-black uppercase tracking-[0.2em] text-rose-500">Security Warning: High Risk Entities Detected</span>
          </div>
        </CardHeader>
        <CardContent className="p-0">
          <Table>
            <TableHeader className="bg-rose-500/[0.03]">
              <TableRow className="hover:bg-transparent border-none">
                <TableHead className="font-black uppercase tracking-[0.2em] text-[9px] h-14 px-8">Entity Identifier</TableHead>
                <TableHead className="font-black uppercase tracking-[0.2em] text-[9px]">Fraud Incident Count</TableHead>
                <TableHead className="font-black uppercase tracking-[0.2em] text-[9px]">Last Known Activity</TableHead>
                <TableHead className="font-black uppercase tracking-[0.2em] text-[9px]">Status</TableHead>
                <TableHead className="text-right font-black uppercase tracking-[0.2em] text-[9px] px-8">Interdiction Control</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {loading ? (
                <TableRow>
                  <TableCell colSpan={5} className="h-64 text-center">
                    <Spinner className="h-8 w-8 text-rose-500 mx-auto" />
                  </TableCell>
                </TableRow>
              ) : fraudUsers.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={5} className="h-64 text-center">
                    <div className="flex flex-col items-center justify-center space-y-4">
                      <div className="p-6 rounded-3xl bg-emerald-500/10 border border-emerald-500/20">
                        <UserCheck className="h-10 w-10 text-emerald-500/40" />
                      </div>
                      <p className="text-xs font-black text-muted-foreground uppercase tracking-widest">No persistently flagged users found.</p>
                    </div>
                  </TableCell>
                </TableRow>
              ) : (
                fraudUsers.map((fu) => (
                  <TableRow key={fu.user_id} className="bg-rose-500/[0.04] hover:bg-rose-500/[0.08] transition-all border-b border-rose-500/10 group">
                    <TableCell className="py-6 px-8">
                       <div className="flex items-center gap-3">
                          <div className="h-8 w-8 rounded-lg bg-rose-500/20 flex items-center justify-center font-black text-rose-500 text-xs italic">
                             {fu.user_id.charAt(0)}
                          </div>
                          <span className="font-black text-sm tracking-tight uppercase italic text-rose-500">{fu.user_id}</span>
                       </div>
                    </TableCell>
                    <TableCell>
                       <div className="flex items-center gap-2">
                          <Badge variant="destructive" className="bg-rose-500 text-white font-black text-[10px] uppercase h-5 px-2">
                             {fu.fraud_count} INCIDENTS
                          </Badge>
                       </div>
                    </TableCell>
                    <TableCell>
                       <div className="flex items-center gap-2 text-muted-foreground">
                          <Clock className="h-3.5 w-3.5" />
                          <span className="text-[10px] font-bold uppercase tracking-widest italic">{fu.last_transaction ? new Date(fu.last_transaction).toLocaleString() : 'N/A'}</span>
                       </div>
                    </TableCell>
                    <TableCell>
                       <div className="flex items-center gap-2 text-rose-500">
                          <div className="h-1.5 w-1.5 rounded-full bg-rose-500 animate-pulse" />
                          <span className="text-[9px] font-black uppercase tracking-widest">PERMANENT_WATCHLIST</span>
                       </div>
                    </TableCell>
                    <TableCell className="text-right px-8">
                       {user.role === 'admin' && (
                          <Button 
                            variant="ghost" 
                            size="sm" 
                            className="text-rose-500 hover:bg-emerald-500 hover:text-white transition-all font-black uppercase tracking-widest text-[9px] h-9 gap-2 group-hover:shadow-lg"
                            onClick={() => handleUnflag(fu.user_id)}
                            disabled={actionId === fu.user_id}
                          >
                             {actionId === fu.user_id ? <Spinner className="h-3 w-3" /> : <UserCheck className="h-3.5 w-3.5" />}
                             REMOVE_FLAG
                          </Button>
                       )}
                    </TableCell>
                  </TableRow>
                ))
              )}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  );
}
