import React, { useState, useEffect, useCallback } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '../components/ui/card';
import { Table, TableHeader, TableBody, TableRow, TableHead, TableCell } from '../components/ui/table';
import { Badge } from '../components/ui/badge';
import { Button } from '../components/ui/button';
import { Spinner } from '../components/ui/spinner';
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, BarChart, Bar, Cell, PieChart, Pie } from 'recharts';
import { rpcCall } from '../api';
import { cn } from '../lib/utils';
import { Activity, ShieldAlert, CheckCircle2, AlertTriangle, TrendingUp, RefreshCw, Zap, ShieldCheck, Globe, Lock, Cpu, User } from 'lucide-react';

export function AnalyticsOverview({ isSimulating, onToggleSimulation }: { isSimulating: boolean, onToggleSimulation: () => void }) {
  const [analytics, setAnalytics] = useState<any>(null);
  const [transactions, setTransactions] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [lastUpdated, setLastUpdated] = useState<string>(new Date().toLocaleTimeString());

  const fetchData = useCallback(async () => {
    try {
      console.log("[FETCH_START] get_analytics and get_transactions");
      const [analyticsData, txData] = await Promise.all([
        rpcCall({ func: 'get_analytics' }),
        rpcCall({ func: 'get_transactions', args: { limit: 12 } })
      ]);
      setAnalytics(analyticsData);
      setTransactions(txData);
      setLastUpdated(new Date().toLocaleTimeString());
      console.log("[FETCH_RESPONSE] Data refreshed successfully");
      setLoading(false);
    } catch (err) {
      console.error("[FETCH_ERROR]", err);
    }
  }, []);

  useEffect(() => {
    fetchData();
    const interval = setInterval(() => {
      if (isSimulating) {
        fetchData();
      }
    }, 5000);
    return () => clearInterval(interval);
  }, [fetchData, isSimulating]);

  const formatRupee = (val: number) => {
    return new Intl.NumberFormat('en-IN', {
      style: 'currency',
      currency: 'INR',
      maximumFractionDigits: 0
    }).format(val);
  };

  if (loading && !analytics) {
    return (
      <div className="flex flex-col items-center justify-center h-[70vh] space-y-8 animate-in fade-in duration-1000">
        <div className="relative group">
          <div className="absolute inset-0 bg-primary/30 rounded-full blur-3xl animate-pulse group-hover:bg-primary/50 transition-all duration-1000" />
          <div className="relative z-10 p-8 rounded-full bg-background border border-primary/20 shadow-[0_0_50px_rgba(var(--primary-rgb),0.2)]">
            <ShieldCheck className="h-16 w-16 text-primary animate-bounce duration-[2000ms]" />
          </div>
        </div>
        <div className="text-center space-y-3">
          <h3 className="text-2xl font-heading font-black tracking-[0.2em] uppercase italic text-foreground/90">FRAUD SYSTEM INITIALIZING</h3>
          <div className="flex items-center justify-center gap-3">
             <div className="h-1 w-24 bg-primary/20 rounded-full overflow-hidden">
                <div className="h-full bg-primary animate-progress-indefinite" />
             </div>
             <p className="text-[10px] font-mono font-bold text-primary animate-pulse uppercase tracking-widest">Establishing Encrypted Link...</p>
             <div className="h-1 w-24 bg-primary/20 rounded-full overflow-hidden">
                <div className="h-full bg-primary animate-progress-indefinite" />
             </div>
          </div>
        </div>
      </div>
    );
  }

  const stats = [
    { label: 'Total Volume', value: analytics?.total_count?.toLocaleString('en-IN') || '0', icon: Activity, color: 'text-blue-500', trend: '+12%' },
    { label: 'Global Fraud Rate', value: `${analytics?.fraud_percentage || '0'}%`, icon: AlertTriangle, color: 'text-amber-500', trend: '-2.4%' },
    { label: 'Active Threats', value: analytics?.fraud_count?.toLocaleString('en-IN') || '0', icon: ShieldAlert, color: 'text-rose-500', trend: 'Critical' },
    { label: 'Average Transaction', value: formatRupee(analytics?.average_amount || 0), icon: Cpu, color: 'text-emerald-500', trend: 'Optimal' },
  ];

  return (
    <div className="space-y-10 animate-in fade-in duration-1000 slide-in-from-bottom-8">
      {/* Premium Hero Banner */}
      <div className="relative rounded-[2.5rem] overflow-hidden border border-white/5 shadow-2xl group min-h-[400px] flex items-center">
        <div className="absolute inset-0 bg-gradient-to-r from-background via-background/60 to-transparent z-10" />
        <img 
          src="./assets/hero-soc-1.jpg" 
          alt="Security Operations Center"
          className="absolute inset-0 w-full h-full object-cover opacity-50 grayscale group-hover:grayscale-0 group-hover:scale-105 transition-all duration-[3000ms]"
        />
        <div className="relative z-20 p-12 md:p-16 space-y-8 max-w-4xl">
          <div className="space-y-4">
            <div className="inline-flex items-center gap-3 px-4 py-1.5 rounded-full bg-primary/10 border border-primary/20 text-[10px] font-black text-primary uppercase tracking-[0.3em] shadow-[0_0_20px_rgba(var(--primary-rgb),0.1)]">
              <div className="h-2 w-2 rounded-full bg-emerald-500 animate-pulse shadow-[0_0_8px_rgba(16,185,129,0.5)]" />
              Mainframe Operational: SEC_ALPHA_7
            </div>
            <h1 className="font-heading text-5xl md:text-7xl font-black tracking-tighter bg-gradient-to-b from-white to-white/40 bg-clip-text text-transparent italic leading-[0.9]">
              FRAUD DETECTION<br/>SYSTEM
            </h1>
            <p className="text-muted-foreground/80 text-lg leading-relaxed max-w-xl font-medium border-l-2 border-primary/40 pl-6 italic">
              Deploying real-time neural inference clusters for global transaction surveillance and adaptive threat neutralisation.
            </p>
          </div>
          <div className="flex flex-wrap items-center gap-6">
            <Button 
              variant={isSimulating ? "destructive" : "default"} 
              size="lg" 
              onClick={onToggleSimulation}
              className="gap-3 h-14 px-10 font-black uppercase tracking-[0.2em] text-xs shadow-[0_0_30px_rgba(var(--primary-rgb),0.4)] hover:scale-105 transition-all rounded-2xl border border-white/10"
            >
              {isSimulating ? <Zap className="h-5 w-5 animate-pulse fill-current" /> : <Activity className="h-5 w-5" />}
              {isSimulating ? "Deactivate Simulation" : "Activate Live Stream"}
            </Button>
            <Button variant="outline" size="lg" className="h-14 px-10 font-black uppercase tracking-[0.2em] text-xs border-white/10 hover:bg-white/5 bg-white/5 backdrop-blur-md rounded-2xl">
              Protocol Manual
            </Button>
          </div>
        </div>
        
        {/* Floating Stat Indicator */}
        <div className="absolute top-12 right-12 hidden 2xl:block z-20">
           <div className="bg-background/40 backdrop-blur-xl p-6 rounded-3xl border border-white/5 space-y-4 shadow-2xl">
              <p className="text-[10px] font-black uppercase tracking-[0.3em] text-primary">Regional Latency</p>
              <div className="space-y-3">
                 {[
                   { r: 'NA_EAST', l: '12ms', s: 'emerald' },
                   { r: 'EU_WEST', l: '24ms', s: 'emerald' },
                   { r: 'AS_SOUTH', l: '86ms', s: 'amber' }
                 ].map(item => (
                   <div key={item.r} className="flex items-center justify-between gap-12">
                      <span className="text-[10px] font-mono font-black opacity-60 italic">{item.r}</span>
                      <div className="flex items-center gap-2">
                        <span className={`text-[10px] font-mono font-black text-${item.s}-500`}>{item.l}</span>
                        <div className={`h-1.5 w-1.5 rounded-full bg-${item.s}-500`} />
                      </div>
                   </div>
                 ))}
              </div>
           </div>
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
        {stats.map((stat, idx) => (
          <Card key={stat.label} className="border-none bg-muted/20 backdrop-blur-md overflow-hidden relative group hover:bg-muted/30 transition-all duration-500 rounded-[2rem] shadow-xl">
            <div className={`absolute top-0 left-0 w-1 h-full bg-${stat.color.split('-')[1]}-500/40 opacity-0 group-hover:opacity-100 transition-opacity`} />
            <CardContent className="p-8">
              <div className="flex items-center justify-between mb-4">
                <div className={cn("rounded-2xl p-3 border border-white/5 shadow-inner", stat.color.replace('text-', 'bg-').replace('500', '500/10'))}>
                  <stat.icon className={cn("h-6 w-6 shadow-sm", stat.color)} />
                </div>
                <Badge variant="outline" className="text-[9px] font-black tracking-[0.2em] uppercase border-white/5 bg-white/5">
                   {stat.trend}
                </Badge>
              </div>
              <div className="space-y-1">
                <div className="text-3xl font-black font-heading italic tracking-tighter">{stat.value}</div>
                <div className="text-[10px] text-muted-foreground font-black uppercase tracking-[0.2em] opacity-60 italic">{stat.label}</div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <Card className="lg:col-span-2 border-none bg-card/40 backdrop-blur-md rounded-[2.5rem] shadow-2xl overflow-hidden min-h-[500px]">
          <CardHeader className="p-10 pb-0">
            <div className="flex items-center justify-between">
               <div>
                  <CardTitle className="font-heading text-2xl font-black tracking-tighter uppercase italic flex items-center gap-3">
                    <TrendingUp className="h-6 w-6 text-primary" /> Heuristic Traffic Flow
                  </CardTitle>
                  <CardDescription className="text-[10px] uppercase font-black tracking-[0.3em] opacity-40 mt-1">Real-time throughput of neural classification nodes</CardDescription>
               </div>
               <div className="flex gap-2">
                 {['1H', '24H', '7D'].map(t => (
                   <button key={t} className={cn("px-4 py-1.5 rounded-xl text-[10px] font-black uppercase tracking-widest border border-white/5 transition-all", t === '1H' ? "bg-primary text-white shadow-lg" : "bg-white/5 hover:bg-white/10")}>
                     {t}
                   </button>
                 ))}
               </div>
            </div>
          </CardHeader>
          <CardContent className="p-10 pt-8 h-[400px]">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={[
                { time: '12:00', volume: 4000, fraud: 240 },
                { time: '13:00', volume: 3000, fraud: 139 },
                { time: '14:00', volume: 2000, fraud: 980 },
                { time: '15:00', volume: 2780, fraud: 390 },
                { time: '16:00', volume: 1890, fraud: 480 },
                { time: '17:00', volume: 2390, fraud: 380 },
                { time: '18:00', volume: 3490, fraud: 430 },
              ]}>
                <defs>
                  <linearGradient id="colorVolume" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="var(--primary)" stopOpacity={0.3}/>
                    <stop offset="95%" stopColor="var(--primary)" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="rgba(255,255,255,0.03)" />
                <XAxis 
                  dataKey="time" 
                  axisLine={false} 
                  tickLine={false} 
                  tick={{ fontSize: 10, fill: 'rgba(255,255,255,0.3)', fontWeight: 'bold' }} 
                  dy={10}
                />
                <YAxis hide />
                <Tooltip 
                  contentStyle={{ backgroundColor: 'rgba(23,23,23,0.8)', border: '1px solid rgba(255,255,255,0.1)', borderRadius: '16px', backdropFilter: 'blur(8px)' }}
                  itemStyle={{ fontSize: 10, fontWeight: 'bold', textTransform: 'uppercase' }}
                />
                <Area type="monotone" dataKey="volume" stroke="var(--primary)" strokeWidth={3} fillOpacity={1} fill="url(#colorVolume)" />
              </AreaChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        <Card className="border-none bg-card/40 backdrop-blur-md rounded-[2.5rem] shadow-2xl overflow-hidden flex flex-col">
          <CardHeader className="p-10">
            <CardTitle className="font-heading text-xl font-black tracking-tighter uppercase italic">Vector Distribution</CardTitle>
            <CardDescription className="text-[10px] uppercase font-black tracking-[0.2em] opacity-40 mt-1">Transaction type entropy breakdown</CardDescription>
          </CardHeader>
          <CardContent className="p-10 pt-0 flex-1 flex flex-col justify-center">
             <div className="h-64 relative">
                <ResponsiveContainer width="100%" height="100%">
                   <PieChart>
                      <Pie
                        data={[
                           { name: 'PAYMENT', value: 40 },
                           { name: 'TRANSFER', value: 30 },
                           { name: 'CASH_OUT', value: 20 },
                           { name: 'OTHER', value: 10 },
                        ]}
                        innerRadius={60}
                        outerRadius={80}
                        paddingAngle={10}
                        dataKey="value"
                        stroke="none"
                      >
                         {[
                           'var(--primary)',
                           'rgba(var(--primary-rgb), 0.7)',
                           'rgba(var(--primary-rgb), 0.4)',
                           'rgba(var(--primary-rgb), 0.2)'
                         ].map((color, index) => (
                           <Cell key={`cell-${index}`} fill={color} cornerRadius={10} />
                         ))}
                      </Pie>
                      <Tooltip />
                   </PieChart>
                </ResponsiveContainer>
                <div className="absolute inset-0 flex flex-col items-center justify-center pointer-events-none">
                   <span className="text-2xl font-black font-heading italic">92%</span>
                   <span className="text-[8px] font-black text-muted-foreground uppercase tracking-widest opacity-60">Verified</span>
                </div>
             </div>
             
             <div className="space-y-4 mt-8">
                {[
                  { label: 'Payment', val: '40.2%', color: 'bg-primary' },
                  { label: 'Transfer', val: '30.1%', color: 'bg-primary/70' },
                  { label: 'Withdrawal', val: '19.7%', color: 'bg-primary/40' },
                ].map(item => (
                  <div key={item.label} className="flex items-center justify-between group">
                     <div className="flex items-center gap-3">
                        <div className={`h-2.5 w-2.5 rounded-full ${item.color} shadow-lg`} />
                        <span className="text-[10px] font-black uppercase tracking-widest opacity-60 group-hover:opacity-100 transition-opacity">{item.label}</span>
                     </div>
                     <span className="text-[10px] font-mono font-black italic">{item.val}</span>
                  </div>
                ))}
             </div>
          </CardContent>
        </Card>
      </div>

      <Card className="border-none bg-card/40 backdrop-blur-md rounded-[2.5rem] shadow-2xl overflow-hidden">
        <CardHeader className="p-10">
          <div className="flex items-center justify-between">
             <div className="flex items-center gap-4">
                <div className="h-10 w-10 rounded-2xl bg-primary/10 flex items-center justify-center border border-primary/20">
                   <Globe className="h-5 w-5 text-primary" />
                </div>
                <div>
                   <CardTitle className="font-heading text-xl font-black tracking-tighter uppercase italic">Active Surveillance Stream</CardTitle>
                   <CardDescription className="text-[10px] uppercase font-black tracking-[0.2em] opacity-40 mt-1">Live heuristic classification queue</CardDescription>
                </div>
             </div>
             <div className="flex items-center gap-3">
                <div className="text-right">
                   <p className="text-[9px] font-mono font-black opacity-40 uppercase">Surveillance Buffer</p>
                   <p className="text-[11px] font-black italic">{lastUpdated}</p>
                </div>
                <Button variant="ghost" size="icon" onClick={() => fetchData()} className="h-10 w-10 hover:bg-white/5 rounded-xl">
                  <RefreshCw className={cn("h-4 w-4", loading && "animate-spin")} />
                </Button>
             </div>
          </div>
        </CardHeader>
        <CardContent className="p-0 border-t border-white/5">
          <Table>
            <TableHeader className="bg-muted/30">
              <TableRow className="border-none">
                <TableHead className="py-6 pl-10 text-[10px] font-black uppercase tracking-[0.2em]">Vector_ID</TableHead>
                <TableHead className="text-[10px] font-black uppercase tracking-[0.2em]">Identifier</TableHead>
                <TableHead className="text-[10px] font-black uppercase tracking-[0.2em]">Vector</TableHead>
                <TableHead className="text-[10px] font-black uppercase tracking-[0.2em]">Volume</TableHead>
                <TableHead className="text-[10px] font-black uppercase tracking-[0.2em]">Classification</TableHead>
                <TableHead className="text-right pr-10 text-[10px] font-black uppercase tracking-[0.2em]">State</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {transactions.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={6} className="h-48 text-center">
                    <div className="flex flex-col items-center justify-center gap-4 py-12 opacity-40">
                       <Lock className="h-12 w-12 text-muted-foreground/30" />
                       <p className="text-[10px] font-black uppercase tracking-[0.3em]">Surveillance queue is empty. Enable simulation.</p>
                    </div>
                  </TableCell>
                </TableRow>
              ) : (
                transactions.map((tx) => (
                  <TableRow key={tx.id} className={cn("border-b border-white/5 hover:bg-white/5 transition-colors group", tx.flagged ? "bg-rose-500/[0.08]" : "")}>
                    <TableCell className="py-6 pl-10">
                       <span className="font-mono text-[10px] font-black text-muted-foreground/60">TXN_{tx.id.toString().padStart(5, '0')}</span>
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center gap-3">
                        <div className="h-8 w-8 rounded-lg bg-muted/50 border border-white/5 flex items-center justify-center">
                           <User className="h-4 w-4 text-muted-foreground" />
                        </div>
                        <span className="font-mono text-xs font-black italic">{tx.user_id}</span>
                      </div>
                    </TableCell>
                    <TableCell>
                      <Badge variant="secondary" className="text-[10px] font-black tracking-widest border-none bg-white/5 uppercase italic">
                        {tx.type}
                      </Badge>
                    </TableCell>
                    <TableCell>
                      <span className="font-mono text-xs font-black">{formatRupee(tx.amount)}</span>
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center gap-4">
                        <Badge 
                          variant={tx.prediction === 'FRAUD' || tx.flagged ? 'destructive' : 'outline'}
                          className={cn(
                            "text-[10px] uppercase font-black px-3 py-1 tracking-tighter border-none rounded-xl italic",
                            tx.prediction === 'FRAUD' || tx.flagged ? "bg-rose-500 text-white animate-pulse shadow-[0_0_15px_rgba(244,63,94,0.3)]" : "bg-emerald-500/10 text-emerald-500"
                          )}
                        >
                          {tx.flagged ? 'FLAGGED' : tx.risk_level}
                        </Badge>
                        <div className="flex flex-col gap-1 w-24">
                           <div className="flex items-center justify-between">
                              <span className="text-[8px] font-black uppercase tracking-widest opacity-40">Confidence</span>
                              <span className="text-[9px] font-mono font-black italic">{(tx.confidence * 100).toFixed(1)}%</span>
                           </div>
                           <div className="h-1 bg-white/5 rounded-full overflow-hidden">
                              <div className={cn("h-full transition-all duration-1000", tx.prediction === 'FRAUD' || tx.flagged ? "bg-rose-500" : "bg-emerald-500")} style={{ width: `${tx.confidence * 100}%` }} />
                           </div>
                        </div>
                      </div>
                    </TableCell>
                    <TableCell className="text-right pr-10">
                       {tx.flagged && (
                         <div className="flex items-center justify-end gap-2 text-rose-500">
                            <ShieldAlert className="h-3.5 w-3.5" />
                            <span className="text-[9px] font-black uppercase tracking-widest">⚠️ INTERDICTED</span>
                         </div>
                       )}
                    </TableCell>
                  </TableRow>
                ))
              )}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
      
      {/* Integration Logos */}
      <div className="flex flex-col items-center gap-8 py-16 border-t border-white/5 opacity-30 grayscale hover:grayscale-0 hover:opacity-100 transition-all duration-1000 cursor-help">
         <p className="text-[10px] font-black uppercase tracking-[0.5em] text-muted-foreground/60 italic">Certified Integration Partners</p>
         <div className="flex flex-wrap justify-center items-center gap-x-20 gap-y-10 px-8">
            <img src="./assets/logo-visa.png" alt="Visa" className="h-7 object-contain brightness-200" />
            <img src="./assets/logo-mastercard.png" alt="Mastercard" className="h-12 object-contain brightness-200" />
            <img src="./assets/logo-stripe.png" alt="Stripe" className="h-9 object-contain brightness-200" />
            <img src="./assets/logo-paypal.png" alt="PayPal" className="h-7 object-contain brightness-200" />
         </div>
         <p className="text-[8px] font-mono font-bold text-muted-foreground uppercase opacity-40">Secure Transaction Handlers • PCI-DSS Tier 1 Compliant</p>
      </div>
    </div>
  );
}
