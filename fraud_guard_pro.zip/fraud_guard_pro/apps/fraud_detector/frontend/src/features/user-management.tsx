import React, { useState, useEffect, useCallback } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '../components/ui/card';
import { Table, TableHeader, TableBody, TableRow, TableHead, TableCell } from '../components/ui/table';
import { Badge } from '../components/ui/badge';
import { Input } from '../components/ui/input';
import { Button } from '../components/ui/button';
import { Switch } from '../components/ui/switch';
import { Spinner } from '../components/ui/spinner';
import { rpcCall, invalidateCache } from '../api';
import { cn } from '../lib/utils';
import { Search, Users, UserX, UserCheck, ShieldAlert, MoreVertical, Ban, RefreshCw, Filter, Lock } from 'lucide-react';

export function UserManagement({ user }: { user: any }) {
  const [users, setUsers] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [updatingId, setUpdatingId] = useState<string | null>(null);

  const isAdmin = user?.role === 'admin';

  const fetchUsers = useCallback(async () => {
    setLoading(true);
    try {
      console.log("[FETCH_START] get_users directory");
      const data = await rpcCall({ func: 'get_users', args: { limit: 100 } });
      setUsers(data);
      console.log("[FETCH_RESPONSE] User directory loaded", data.length);
    } catch (err) {
      console.error("[FETCH_ERROR]", err);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchUsers();
  }, [fetchUsers]);

  const toggleUserStatus = async (user_id: string, currentlyBlacklisted: boolean) => {
    if (!isAdmin) return;
    
    setUpdatingId(user_id);
    const newStatus = currentlyBlacklisted ? 'active' : 'fraud';
    console.log("[ACTION_START] flag_user", { user_id, newStatus });
    try {
      await rpcCall({ func: 'flag_user', args: { user_id, status: newStatus } });
      setUsers(prev => prev.map(u => u.id === user_id ? { ...u, isBlacklisted: !currentlyBlacklisted } : u));
      invalidateCache(['get_transactions', 'get_analytics']);
      console.log("[FETCH_RESPONSE] User status updated");
    } catch (err) {
      console.error("[FETCH_ERROR]", err);
    } finally {
      setUpdatingId(null);
    }
  };

  const filteredUsers = users.filter(u => u.id.toLowerCase().includes(search.toLowerCase()));

  return (
    <div className="space-y-6 max-w-5xl mx-auto py-4 animate-in fade-in duration-500">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div className="flex items-center gap-4">
           <div className="h-12 w-12 rounded-2xl bg-primary/10 flex items-center justify-center border border-primary/20 shadow-lg">
              <Users className="h-6 w-6 text-primary" />
           </div>
           <div>
             <h2 className="font-heading text-2xl font-black tracking-tighter uppercase italic">Access Control Registry</h2>
             <p className="text-muted-foreground text-[10px] font-bold uppercase tracking-widest opacity-60">Manage identity clearance and interdiction status</p>
           </div>
        </div>
        <div className="flex items-center gap-2">
           <Button variant="outline" size="sm" className="gap-2 h-10 font-black uppercase tracking-widest text-[10px]" onClick={() => fetchUsers()}>
             <RefreshCw className={cn("h-4 w-4", loading && "animate-spin")} />
             Sync Directory
           </Button>
           {isAdmin && (
             <Button size="sm" className="gap-2 h-10 font-black uppercase tracking-widest text-[10px]">
               <Ban className="h-4 w-4" />
               Manual Interdict
             </Button>
           )}
        </div>
      </div>

      {!isAdmin && (
        <div className="p-4 rounded-2xl bg-amber-500/10 border border-amber-500/20 flex items-center gap-3 text-amber-500">
           <Lock className="h-5 w-5" />
           <p className="text-[10px] font-black uppercase tracking-widest">Read-Only Mode: Elevate to ADMIN for modification rights.</p>
        </div>
      )}

      <Card className="border-muted shadow-2xl overflow-hidden bg-card/30 backdrop-blur-md">
        <CardHeader className="bg-muted/10 pb-6 pt-6 border-b border-muted px-6">
           <div className="flex items-center gap-4">
              <div className="relative flex-1 group">
                <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground group-focus-within:text-primary transition-colors" />
                <Input 
                  placeholder="Query identity identifiers..." 
                  className="pl-10 bg-background/50 h-12 font-mono text-xs font-bold tracking-tight border-muted" 
                  value={search}
                  onChange={e => setSearch(e.target.value)}
                />
              </div>
              <Button variant="outline" size="icon" className="h-12 w-12 border-muted hover:bg-muted">
                <Filter className="h-4 w-4" />
              </Button>
           </div>
        </CardHeader>
        <CardContent className="p-0">
          <Table>
            <TableHeader className="bg-muted/30">
              <TableRow className="border-none">
                <TableHead className="font-black uppercase tracking-[0.2em] text-[9px] py-4 pl-8">Entity Identifier</TableHead>
                <TableHead className="font-black uppercase tracking-[0.2em] text-[9px]">Clearance Class</TableHead>
                <TableHead className="font-black uppercase tracking-[0.2em] text-[9px]">Cycle Ingress</TableHead>
                <TableHead className="font-black uppercase tracking-[0.2em] text-[9px]">Interdiction Lock</TableHead>
                <TableHead className="text-right font-black uppercase tracking-[0.2em] text-[9px] pr-8">Audit</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {loading ? (
                <TableRow>
                  <TableCell colSpan={5} className="h-64 text-center">
                    <div className="flex flex-col items-center justify-center space-y-4">
                      <Spinner className="h-8 w-8 text-primary" />
                      <p className="text-[10px] text-muted-foreground animate-pulse uppercase tracking-[0.3em] font-black italic">Verifying clearance profiles...</p>
                    </div>
                  </TableCell>
                </TableRow>
              ) : filteredUsers.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={5} className="h-64 text-center">
                    <div className="flex flex-col items-center justify-center space-y-4">
                      <div className="p-6 rounded-3xl bg-muted/20 border border-muted border-dashed">
                        <Users className="h-10 w-10 text-muted-foreground/20" />
                      </div>
                      <p className="text-[10px] font-black text-muted-foreground uppercase tracking-widest">Null query results in registry</p>
                    </div>
                  </TableCell>
                </TableRow>
              ) : (
                filteredUsers.map((u) => (
                  <TableRow key={u.id} className={cn("transition-all border-b border-muted/20 group", u.isBlacklisted ? "bg-rose-500/[0.04] hover:bg-rose-500/[0.08]" : "hover:bg-muted/40")}>
                    <TableCell className="py-6 pl-8">
                       <div className="flex items-center gap-4">
                         <div className={cn(
                           "h-10 w-10 rounded-xl flex items-center justify-center border-2 transition-transform group-hover:scale-110",
                           u.isBlacklisted ? "bg-rose-500/10 border-rose-500/20 text-rose-500" : "bg-emerald-500/10 border-emerald-500/20 text-emerald-500"
                         )}>
                            {u.isBlacklisted ? <UserX className="h-5 w-5" /> : <UserCheck className="h-5 w-5" />}
                         </div>
                         <div className="flex flex-col">
                            <span className="font-black text-sm font-heading tracking-tight italic uppercase">{u.id}</span>
                            <span className="text-[9px] text-muted-foreground/60 font-bold uppercase tracking-tighter">Latent: {new Date(u.lastSeen).toLocaleDateString()}</span>
                         </div>
                       </div>
                    </TableCell>
                    <TableCell>
                       <Badge variant={u.isBlacklisted ? 'destructive' : 'outline'} className={cn(
                         "text-[9px] uppercase font-black h-5 px-2 border-none",
                         u.isBlacklisted ? "bg-rose-500 text-white animate-pulse" : "bg-muted text-muted-foreground"
                       )}>
                         {u.isBlacklisted ? 'RESTRICTED' : 'VERIFIED'}
                       </Badge>
                    </TableCell>
                    <TableCell>
                       <div className="flex flex-col gap-1.5">
                          <span className="text-[10px] font-mono font-black italic">{u.transactionCount} Vectors Logged</span>
                          <div className="w-24 bg-muted/40 h-1 rounded-full overflow-hidden border border-white/5">
                             <div className="bg-primary h-full rounded-full" style={{ width: `${Math.min(u.transactionCount * 5, 100)}%` }} />
                          </div>
                       </div>
                    </TableCell>
                    <TableCell>
                       <div className="flex items-center gap-3">
                         <Switch 
                           checked={u.isBlacklisted} 
                           onCheckedChange={() => toggleUserStatus(u.id, u.isBlacklisted)}
                           disabled={updatingId === u.id || !isAdmin}
                           className={cn(u.isBlacklisted && "data-[state=checked]:bg-rose-500")}
                         />
                         {updatingId === u.id ? <Spinner className="h-3 w-3" /> : u.isBlacklisted ? <ShieldAlert className="h-4 w-4 text-rose-500 animate-pulse" /> : null}
                       </div>
                    </TableCell>
                    <TableCell className="text-right pr-8">
                       <Button variant="ghost" size="icon" className="h-9 w-9 text-muted-foreground hover:bg-muted hover:text-primary transition-all">
                         <MoreVertical className="h-4 w-4" />
                       </Button>
                    </TableCell>
                  </TableRow>
                ))
              )}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mt-8">
        <Card className="bg-rose-500/[0.03] border-rose-500/20 border-dashed rounded-3xl overflow-hidden relative">
          <div className="absolute top-0 right-0 p-4 opacity-10">
             <ShieldAlert className="h-12 w-12 text-rose-500" />
          </div>
          <CardHeader className="pb-3 px-8 pt-8">
             <CardTitle className="text-[11px] font-black uppercase tracking-[0.2em] text-rose-500 flex items-center gap-2">
               <ShieldAlert className="h-4 w-4" /> Global Interdiction Policy
             </CardTitle>
          </CardHeader>
          <CardContent className="px-8 pb-8">
             <p className="text-[10px] text-rose-500/70 leading-relaxed font-medium italic">
               "Identities locked in the registry are automatically blocked from all origin vectors. Neural risk scores for restricted entities are calculated with a mandatory 0.7 probability offset."
             </p>
          </CardContent>
        </Card>
        <Card className="bg-emerald-500/[0.03] border-emerald-500/20 border-dashed rounded-3xl overflow-hidden relative">
          <div className="absolute top-0 right-0 p-4 opacity-10">
             <UserCheck className="h-12 w-12 text-emerald-500" />
          </div>
          <CardHeader className="pb-3 px-8 pt-8">
             <CardTitle className="text-[11px] font-black uppercase tracking-[0.2em] text-emerald-500 flex items-center gap-2">
               <UserCheck className="h-4 w-4" /> Behavioral Clearance
             </CardTitle>
          </CardHeader>
          <CardContent className="px-8 pb-8">
             <p className="text-[10px] text-emerald-500/70 leading-relaxed font-medium italic">
               "Identities exceeding 100 genuine cycles with zero interdiction hits are granted accelerated clearance. Friction thresholds are reduced by 15% for all incoming vectors."
             </p>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
