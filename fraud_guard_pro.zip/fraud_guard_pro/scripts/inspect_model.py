import joblib
import pandas as pd
import numpy as np

try:
    model = joblib.load('Models/fraud_model.pkl')
    print(f"Model type: {type(model)}")
    
    if hasattr(model, 'feature_name_'):
        print(f"Feature names: {model.feature_name_}")
    
    if hasattr(model, 'n_features_in_'):
        print(f"Number of input features: {model.n_features_in_}")
        
    if hasattr(model, 'classes_'):
        print(f"Classes: {model.classes_}")

    # Test with a dummy input based on src/app.py logic
    # features = [[type_map.get(transaction.type.upper(), 0), amount, oldbalanceOrg, newbalanceOrig, oldbalanceDest, newbalanceDest]]
    test_input = np.array([[0, 1000.0, 5000.0, 4000.0, 0.0, 1000.0]])
    prediction = model.predict(test_input)
    proba = model.predict_proba(test_input)
    print(f"Test Prediction: {prediction}")
    print(f"Test Probability: {proba}")

except Exception as e:
    print(f"Error inspecting model: {e}")
