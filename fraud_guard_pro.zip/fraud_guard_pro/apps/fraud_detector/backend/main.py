from apps.fraud_detector.backend.db import (
    init_db, 
    fetch_transactions, 
    fetch_analytics, 
    upsert_user, 
    delete_transaction, 
    update_transaction_flag,
    fetch_fraud_users,
    unflag_user as db_unflag_user
)
from apps.fraud_detector.backend.services import run_prediction, generate_simulation

# Initialize DB on first import
init_db()

def login(username, password):
    print(f"[BACKEND_START] login attempt for {username}")
    # Simple username/password auth as requested
    # Admin: admin / admin
    # User: user / user
    users = {
        "admin": {"password": "admin", "role": "admin"},
        "user": {"password": "user", "role": "user"}
    }
    
    user = users.get(username)
    if user and user["password"] == password:
        print(f"[BACKEND_SUCCESS] login successful for {username}")
        return {"username": username, "role": user["role"]}
    
    print(f"[BACKEND_ERROR] login failed for {username}")
    return None

def predict_transaction(user_id: str, type: str, amount: float, oldbalanceOrg: float, newbalanceOrig: float, oldbalanceDest: float, newbalanceDest: float):
    print(f"[BACKEND_START] predict_transaction called for user_id={user_id}")
    try:
        tx_data = {
            'user_id': user_id,
            'type': type,
            'amount': amount,
            'oldbalanceOrg': oldbalanceOrg,
            'newbalanceOrig': newbalanceOrig,
            'oldbalanceDest': oldbalanceDest,
            'newbalanceDest': newbalanceDest
        }
        result = run_prediction(tx_data)
        print(f"[BACKEND_SUCCESS] predict_transaction result: prediction={result.get('prediction')}, confidence={result.get('confidence')}")
        return result
    except Exception as e:
        print(f"[BACKEND_ERROR] predict_transaction failed: {str(e)}")
        raise

def get_transactions(limit: int = 50, filter_type: str = 'all'):
    print(f"[BACKEND_START] get_transactions called with limit={limit}, filter_type={filter_type}")
    try:
        results = fetch_transactions(limit=limit, filter_type=filter_type)
        print(f"[BACKEND_SUCCESS] get_transactions returning {len(results)} records")
        return results
    except Exception as e:
        print(f"[BACKEND_ERROR] get_transactions failed: {str(e)}")
        raise

def remove_transaction(tx_id: int):
    print(f"[BACKEND_START] remove_transaction called for tx_id={tx_id}")
    try:
        result = delete_transaction(tx_id)
        print(f"[BACKEND_SUCCESS] remove_transaction tx_id={tx_id} deleted")
        return result
    except Exception as e:
        print(f"[BACKEND_ERROR] remove_transaction failed: {str(e)}")
        raise

def toggle_transaction_flag(tx_id: int, flagged: bool):
    print(f"[BACKEND_START] toggle_transaction_flag called for tx_id={tx_id}, flagged={flagged}")
    try:
        result = update_transaction_flag(tx_id, flagged)
        print(f"[BACKEND_SUCCESS] toggle_transaction_flag tx_id={tx_id} set to {flagged}")
        return result
    except Exception as e:
        print(f"[BACKEND_ERROR] toggle_transaction_flag failed: {str(e)}")
        raise

def get_analytics():
    print(f"[BACKEND_START] get_analytics called")
    try:
        analytics = fetch_analytics()
        print(f"[BACKEND_SUCCESS] get_analytics result: {analytics}")
        return analytics
    except Exception as e:
        print(f"[BACKEND_ERROR] get_analytics failed: {str(e)}")
        raise

def simulate_transactions(count: int = 5):
    print(f"[BACKEND_START] simulate_transactions called with count={count}")
    try:
        results = generate_simulation(count=count)
        print(f"[BACKEND_SUCCESS] simulate_transactions completed {len(results)} transactions")
        return results
    except Exception as e:
        print(f"[BACKEND_ERROR] simulate_transactions failed: {str(e)}")
        raise

def flag_user(user_id: str, status: str = 'fraud'):
    print(f"[BACKEND_START] flag_user called for user_id={user_id}, status={status}")
    try:
        upsert_user(user_id, status=status)
        print(f"[BACKEND_SUCCESS] flag_user user={user_id} updated to status={status}")
        return {"success": True, "user_id": user_id, "status": status}
    except Exception as e:
        print(f"[BACKEND_ERROR] flag_user failed: {str(e)}")
        raise

def unflag_user(user_id: str):
    print(f"[BACKEND_START] unflag_user called for user_id={user_id}")
    try:
        result = db_unflag_user(user_id)
        print(f"[BACKEND_SUCCESS] unflag_user successful for user_id={user_id}")
        return result
    except Exception as e:
        print(f"[BACKEND_ERROR] unflag_user failed: {str(e)}")
        raise

def get_fraud_users():
    print(f"[BACKEND_START] get_fraud_users called")
    try:
        results = fetch_fraud_users()
        print(f"[BACKEND_SUCCESS] get_fraud_users returning {len(results)} users")
        return results
    except Exception as e:
        print(f"[BACKEND_ERROR] get_fraud_users failed: {str(e)}")
        raise

def predict_batch(transactions: list[dict]):
    print(f"[BACKEND_START] predict_batch called with {len(transactions)} transactions")
    try:
        results = []
        for tx_data in transactions:
            result = run_prediction(tx_data)
            results.append(result)
        print(f"[BACKEND_SUCCESS] predict_batch completed {len(results)} predictions")
        return results
    except Exception as e:
        print(f"[BACKEND_ERROR] predict_batch failed: {str(e)}")
        raise

__all__ = ["login", "predict_transaction", "get_transactions", "remove_transaction", "toggle_transaction_flag", "get_analytics", "simulate_transactions", "flag_user", "predict_batch", "get_fraud_users", "unflag_user"]
