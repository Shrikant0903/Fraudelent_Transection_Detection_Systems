from nexttoken import NextToken
import json

client = NextToken()

def check_github():
    print("[CHECK_START] Searching for fraud-guard-pro repository...")
    try:
        # Fetch repositories with owner affiliation
        result = client.integrations.invoke(
            app="github",
            function_key="github-list-repositories",
            args={
                "affiliation": ["owner"],
                "sort": "updated",
                "direction": "desc"
            }
        )
        
        # In NextToken SDK, the actual action output is inside result["result"]
        # Depending on the integration, result["result"] might be the list itself, 
        # or it might be an object containing the list.
        action_output = result.get("result", [])
        
        # If result is a dict with a "repositories" or similar key, we handle it
        repos = []
        if isinstance(action_output, list):
            repos = action_output
        elif isinstance(action_output, dict):
            # Sometimes GitHub API returns a list, but Pipedream may wrap it
            for key in ["repositories", "repos", "items"]:
                if isinstance(action_output.get(key), list):
                    repos = action_output[key]
                    break
        
        found = False
        for repo in repos:
            if isinstance(repo, dict) and repo.get("name") == "fraud-guard-pro":
                print(f"[CHECK_SUCCESS] Found repository: {repo.get('full_name')}")
                print(f"URL: {repo.get('html_url')}")
                found = True
                break
        
        if not found:
            print("[CHECK_INFO] Repository 'fraud-guard-pro' not found.")
            if repos:
                recent = [r.get("name") for r in repos[:5] if isinstance(r, dict)]
                print(f"Your recent repositories: {', '.join(recent)}")
            else:
                print("No owner-affiliated repositories found.")
            
    except Exception as e:
        print(f"[CHECK_ERROR] Failed to check GitHub: {str(e)}")

if __name__ == "__main__":
    check_github()
