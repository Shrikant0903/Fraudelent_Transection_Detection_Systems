import sqlite3
import os

DB_DIR = "apps/fraud_detector/backend/data/db"
DB_PATH = os.path.join(DB_DIR, "fraud.db")

def _get_db():
    """Open a connection with recommended settings."""
    os.makedirs(DB_DIR, exist_ok=True)
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA journal_mode=WAL")
    conn.execute("PRAGMA foreign_keys=ON")
    return conn

def init_db():
    """Initialize the database with tables."""
    conn = _get_db()
    try:
        conn.execute("""
            CREATE TABLE IF NOT EXISTS users (
                user_id TEXT PRIMARY KEY,
                status TEXT DEFAULT 'active'
            )
        """)
        conn.execute("""
            CREATE TABLE IF NOT EXISTS transactions (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id TEXT NOT NULL,
                type TEXT NOT NULL,
                amount REAL NOT NULL,
                oldbalanceOrg REAL NOT NULL,
                newbalanceOrig REAL NOT NULL,
                oldbalanceDest REAL NOT NULL,
                newbalanceDest REAL NOT NULL,
                prediction TEXT NOT NULL,
                confidence REAL NOT NULL,
                risk_level TEXT NOT NULL,
                flagged BOOLEAN NOT NULL,
                timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (user_id) REFERENCES users(user_id)
            )
        """)
        # Add indexes for faster analytics and filtering
        conn.execute("CREATE INDEX IF NOT EXISTS idx_transactions_user_id ON transactions(user_id)")
        conn.execute("CREATE INDEX IF NOT EXISTS idx_transactions_prediction ON transactions(prediction)")
        conn.execute("CREATE INDEX IF NOT EXISTS idx_transactions_flagged ON transactions(flagged)")
        conn.execute("CREATE INDEX IF NOT EXISTS idx_transactions_timestamp ON transactions(timestamp)")
        conn.commit()
    finally:
        conn.close()

def upsert_user(user_id, status='active'):
    conn = _get_db()
    try:
        conn.execute("INSERT OR REPLACE INTO users (user_id, status) VALUES (?, ?)", (user_id, status))
        conn.commit()
    finally:
        conn.close()

def get_user_status(user_id):
    conn = _get_db()
    try:
        row = conn.execute("SELECT status FROM users WHERE user_id = ?", (user_id,)).fetchone()
        return row['status'] if row else 'active'
    finally:
        conn.close()

def insert_transaction(tx_data):
    conn = _get_db()
    try:
        cursor = conn.execute("""
            INSERT INTO transactions (
                user_id, type, amount, oldbalanceOrg, newbalanceOrig, oldbalanceDest, newbalanceDest,
                prediction, confidence, risk_level, flagged
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            tx_data['user_id'], tx_data['type'], tx_data['amount'],
            tx_data['oldbalanceOrg'], tx_data['newbalanceOrig'],
            tx_data['oldbalanceDest'], tx_data['newbalanceDest'],
            tx_data['prediction'], tx_data['confidence'],
            tx_data['risk_level'], tx_data['flagged']
        ))
        conn.commit()
        tx_id = cursor.lastrowid
        row = dict(conn.execute("SELECT * FROM transactions WHERE id = ?", (tx_id,)).fetchone())
        row['flagged'] = bool(row['flagged'])
        return row
    finally:
        conn.close()

def fetch_transactions(limit=50, filter_type='all'):
    conn = _get_db()
    try:
        query = "SELECT * FROM transactions"
        params = []
        if filter_type == 'flagged':
            query += " WHERE flagged = 1"
        elif filter_type == 'non-flagged':
            query += " WHERE flagged = 0"
        
        query += " ORDER BY timestamp DESC LIMIT ?"
        params.append(limit)
        
        rows = conn.execute(query, params).fetchall()
        results = []
        for r in rows:
            d = dict(r)
            d['flagged'] = bool(d['flagged'])
            results.append(d)
        return results
    finally:
        conn.close()

def delete_transaction(tx_id):
    conn = _get_db()
    try:
        conn.execute("DELETE FROM transactions WHERE id = ?", (tx_id,))
        conn.commit()
        return {"success": True, "id": tx_id}
    finally:
        conn.close()

def update_transaction_flag(tx_id, flagged):
    conn = _get_db()
    try:
        conn.execute("UPDATE transactions SET flagged = ? WHERE id = ?", (1 if flagged else 0, tx_id))
        conn.commit()
        row = dict(conn.execute("SELECT * FROM transactions WHERE id = ?", (tx_id,)).fetchone())
        row['flagged'] = bool(row['flagged'])
        return row
    finally:
        conn.close()

def fetch_fraud_users():
    conn = _get_db()
    try:
        # Status 'fraud' is used for blacklisted users
        # Fetch user_id, count of fraud transactions, and last transaction date
        rows = conn.execute("""
            SELECT 
                u.user_id, 
                COUNT(t.id) as fraud_count, 
                MAX(t.timestamp) as last_transaction
            FROM users u
            LEFT JOIN transactions t ON u.user_id = t.user_id AND t.prediction = 'FRAUD'
            WHERE u.status = 'fraud'
            GROUP BY u.user_id
        """).fetchall()
        return [dict(r) for r in rows]
    finally:
        conn.close()

def unflag_user(user_id):
    conn = _get_db()
    try:
        conn.execute("UPDATE users SET status = 'active' WHERE user_id = ?", (user_id,))
        conn.commit()
        return {"success": True, "user_id": user_id}
    finally:
        conn.close()

def fetch_users(limit=100):
    conn = _get_db()
    try:
        # Fetch all users and their transaction summary
        rows = conn.execute("""
            SELECT 
                u.user_id as id,
                COUNT(t.id) as transactionCount,
                u.status = 'fraud' as isBlacklisted,
                MAX(t.timestamp) as lastSeen,
                EXISTS(SELECT 1 FROM transactions WHERE user_id = u.user_id AND prediction = 'FRAUD') as hasFraud
            FROM users u
            LEFT JOIN transactions t ON u.user_id = t.user_id
            GROUP BY u.user_id
            ORDER BY lastSeen DESC
            LIMIT ?
        """, (limit,)).fetchall()
        return [dict(r) for r in rows]
    finally:
        conn.close()

def fetch_analytics():
    conn = _get_db()
    try:
        total = conn.execute("SELECT COUNT(*) FROM transactions").fetchone()[0]
        if total == 0:
            return {
                "total_count": 0,
                "fraud_count": 0,
                "fraud_percentage": 0,
                "flagged_count": 0,
                "average_amount": 0
            }
        
        fraud_count = conn.execute("SELECT COUNT(*) FROM transactions WHERE prediction = 'FRAUD'").fetchone()[0]
        flagged_count = conn.execute("SELECT COUNT(*) FROM transactions WHERE flagged = 1").fetchone()[0]
        avg_amount = conn.execute("SELECT AVG(amount) FROM transactions").fetchone()[0]
        
        return {
            "total_count": total,
            "fraud_count": fraud_count,
            "fraud_percentage": round((fraud_count / total) * 100, 2),
            "flagged_count": flagged_count,
            "average_amount": round(avg_amount, 2)
        }
    finally:
        conn.close()
