import joblib
import pandas as pd
import os
import random
from apps.fraud_detector.backend.db import insert_transaction, upsert_user, get_user_status

# Feature order: ['type', 'amount', 'oldbalanceOrg', 'newbalanceOrig', 'oldbalanceDest', 'newbalanceDest']
# Type mapping: PAYMENT: 0, TRANSFER: 1, CASH_OUT: 2, DEBIT: 3, CASH_IN: 4.

TYPE_MAP = {
    'PAYMENT': 0,
    'TRANSFER': 1,
    'CASH_OUT': 2,
    'DEBIT': 3,
    'CASH_IN': 4
}

REV_TYPE_MAP = {v: k for k, v in TYPE_MAP.items()}

MODEL_PATH = 'Models/fraud_model.pkl'

def get_risk_level(prediction, confidence):
    if prediction == 'FRAUD':
        if confidence >= 0.8: return 'High'
        if confidence >= 0.5: return 'Medium'
        return 'Low'
    else:
        if confidence >= 0.3: return 'Low'
        return 'Low'

def run_prediction(tx_data):
    print(f"[BACKEND_START] run_prediction for user_id={tx_data.get('user_id')}")
    
    if not os.path.exists(MODEL_PATH):
        raise FileNotFoundError(f"Model file not found at {MODEL_PATH}")
    
    model = joblib.load(MODEL_PATH)
    
    # Check if user is already blacklisted
    user_status = get_user_status(tx_data['user_id'])
    is_blacklisted = user_status == 'fraud'
    
    # Prepare features for prediction
    type_code = TYPE_MAP.get(tx_data['type'], 0)
    features = [
        type_code,
        tx_data['amount'],
        tx_data['oldbalanceOrg'],
        tx_data['newbalanceOrig'],
        tx_data['oldbalanceDest'],
        tx_data['newbalanceDest']
    ]
    
    # ML Prediction
    df = pd.DataFrame([features], columns=['type', 'amount', 'oldbalanceOrg', 'newbalanceOrig', 'oldbalanceDest', 'newbalanceDest'])
    probs = model.predict_proba(df)[0]
    
    # Assuming class 1 is FRAUD
    fraud_prob = float(probs[1])
    
    # PERSISTENT FRAUD USER LOGIC (Requirement 5)
    # If a user is already flagged, automatically mark as fraud and override logic
    if is_blacklisted:
        prediction_label = 'FRAUD'
        fraud_prob = 1.0  # Max confidence for persistent fraud
        risk_level = 'High'
        warning = "⚠️ User already flagged as fraud"
        flagged = True
    else:
        # Label as FRAUD if prob >= 0.3 (standard threshold for this dataset)
        prediction_label = 'FRAUD' if fraud_prob >= 0.3 else 'GENUINE'
        risk_level = get_risk_level(prediction_label, fraud_prob)
        warning = None
        flagged = bool(fraud_prob >= 0.3)
    
    # If the current prediction is FRAUD, ensure the user is stored as 'fraud'
    if prediction_label == 'FRAUD':
        user_status = 'fraud'
    
    result_data = {
        **tx_data,
        'prediction': prediction_label,
        'confidence': round(fraud_prob, 4),
        'risk_level': risk_level,
        'flagged': flagged,
        'warning': warning
    }
    
    # Upsert user to ensure status is updated and FK is satisfied
    upsert_user(tx_data['user_id'], user_status)
    
    # Persist to DB
    saved_tx = insert_transaction(result_data)
    
    print(f"[BACKEND_SUCCESS] run_prediction complete for user_id={tx_data.get('user_id')} - Result: {prediction_label}")
    return saved_tx

def generate_simulation(count=5):
    print(f"[BACKEND_START] generate_simulation count={count}")
    results = []
    
    for _ in range(count):
        user_id = f"U{random.randint(10000, 99999)}"
        tx_type = random.choice(list(TYPE_MAP.keys()))
        amount = random.uniform(10, 10000)
        
        # Some "fraudulent" looking ones
        if random.random() < 0.2:
            amount = random.uniform(50000, 200000)
            tx_type = 'TRANSFER'
        
        old_orig = random.uniform(amount, amount * 2)
        new_orig = old_orig - amount
        old_dest = random.uniform(0, 5000)
        new_dest = old_dest + amount
        
        tx_data = {
            'user_id': user_id,
            'type': tx_type,
            'amount': amount,
            'oldbalanceOrg': old_orig,
            'newbalanceOrig': new_orig,
            'oldbalanceDest': old_dest,
            'newbalanceDest': new_dest
        }
        
        # This will predict and save
        saved = run_prediction(tx_data)
        results.append(saved)
        
    print(f"[BACKEND_SUCCESS] generate_simulation generated {len(results)} transactions")
    return results
